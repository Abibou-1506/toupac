# TOUPAC — Architecture Document v1.0

**Projet** : TOUPAC — TMS SaaS multi-tenant pour le transport ouest-africain  
**Auteur** : Architecte technique principal  
**Date** : 24 août 2026  
**Statut** : Draft — Section 1  
**Scope** : Choix de stack technique pour le développement sur-mesure (Option C validée)

---

## Section 1 — Choix de stack technique

### 1.0 Préambule : ce qui est récupérable du travail Fleetbase

Deux sprints de développement sur Fleetbase ont produit du **domain knowledge** directement portable, quel que soit le framework choisi :

| Actif | Réutilisable tel quel ? | Comment |
|---|:---:|---|
| Contrat OpenAPI v1.1.0 (19 endpoints) | ✅ Oui | Framework-agnostic — sert de spécification pour la réécriture |
| Protocole offline-sync (batch events, idempotence `client_uuid`, auto-anomalies, réconciliation) | ✅ Oui | Pattern applicatif, pas couplé à Laravel |
| QR billet JWT RS256 (vérifiable offline) | ✅ Oui | Librairies JWT disponibles dans tous les langages |
| Schéma DB 12 tables custom (passengers, reservations, control_sessions, etc.) | ✅ Oui | Migration DDL → PostgreSQL directe |
| Collection Postman 20 requêtes | ✅ Oui | Tests de non-régression pour la nouvelle API |
| Leçons techniques (§4.1–4.19 du J5-STATE) | ✅ Oui | Pièges à éviter, patterns validés |
| Code PHP Laravel (controllers, models, services, observers) | ⚠️ Partiel | Logique métier portable, syntaxe à réécrire |
| Code spécifique Fleetbase (OrderConfig, Payload, Entity facades) | ❌ Non | Couplé au data model Fleetbase — remplacé par un modèle propre |

**Conclusion** : le choix de framework ne doit **pas** être dicté par la volonté de réutiliser du code PHP. Le vrai actif — patterns métier, contrat API, protocole offline — est framework-agnostic. Le critère de décision est le **time-to-market V1** et la **recrutabilité long terme**.

---

### 1.1 Framework backend

#### Option A — Laravel 11 (PHP 8.3+)

| Critère | Évaluation |
|---|---|
| **Maturité** | Excellent — framework PHP le plus populaire, écosystème riche (Sanctum, Horizon, Telescope, Filament) |
| **Performance** | Très bon avec Octane/FrankenPHP (leçon apprise sur Fleetbase §4.13 : worker persistant en mémoire) |
| **Admin panel** | Filament PHP (gratuit, moderne, puissant) — comparable à Django Admin en productivité |
| **Multi-tenant** | `stancl/tenancy` mature — isolation par DB ou par colonne |
| **Recrutabilité AO** | Bonne à Dakar, Abidjan — PHP reste très répandu mais tendance déclinante chez les juniors |
| **Continuité** | Familiarité acquise sur 2 sprints, mais le code Fleetbase n'est pas portable tel quel |

**Trade-off** : écosystème riche et éprouvé, mais recrutabilité en déclin et le code existant n'apporte pas d'avantage décisif puisqu'on repart sur un data model propre.

#### Option B — Django 5.x + Django REST Framework (Python 3.12+)

| Critère | Évaluation |
|---|---|
| **Maturité** | Excellent — 20 ans d'existence, "batteries included" (ORM, auth, admin, forms, migrations) |
| **Performance** | Bon avec gunicorn + uvicorn workers, async views natifs depuis Django 4.1 |
| **Admin panel** | Django Admin natif — accélérateur majeur pour un MVP multi-tenant. Habillable avec django-unfold |
| **Multi-tenant** | `django-tenants` (isolation par schéma PostgreSQL) ou `django-multitenant` (row-level isolation par `tenant_id`) |
| **Spatial** | GeoDjango — intégration PostGIS native, le meilleur support géospatial de tous les frameworks web |
| **Recrutabilité AO** | Excellente — Python est le langage le plus enseigné dans les écoles d'ingénieurs ouest-africaines (ESP Dakar, ESMT, INP-HB Yamoussoukro, IPNet Abidjan) |
| **Continuité** | Réécriture des patterns métier, mais la logique est documentée dans l'OpenAPI |

**Trade-off** : meilleure recrutabilité et meilleur support géospatial natif, mais réécriture complète du code (atténuée par la documentation exhaustive existante).

#### Option C — Django + FastAPI (hybride, recommandation de l'étude initiale)

| Critère | Évaluation |
|---|---|
| **Idée** | Django pour l'ORM/admin/RBAC, FastAPI pour l'API publique haute performance |
| **Avantage théorique** | FastAPI est ~3× plus rapide que DRF sur les benchmarks bruts (async natif, Pydantic) |
| **Inconvénient** | Deux frameworks à maintenir, deux sets de middlewares, deux systèmes d'auth à synchroniser, duplication de la couche de validation |
| **Recrutabilité** | Complexifie le profil recherché : le dev doit maîtriser Django ET FastAPI |

**Trade-off** : gain de performance marginal pour le use case TOUPAC (on vise < 2s, pas < 50ms) contre une complexité opérationnelle significative.

#### ➤ Recommandation : Django 5.x + DRF (Option B)

**Justification en 3 points :**

1. **GeoDjango** est sans équivalent pour un TMS : requêtes spatiales (chauffeurs à proximité, géofencing, zones de service) en une ligne de code ORM au lieu de SQL brut.
2. **Django Admin + django-unfold** donne un back-office complet en quelques jours — critique pour un MVP où chaque semaine compte. Filament pour Laravel est comparable, mais Django Admin a 15 ans de maturité de plus.
3. **Recrutabilité** : Python domine dans les formations en Afrique de l'Ouest. Sur 3 ans, c'est le facteur le plus structurant pour une startup basée à Dakar.

**Pourquoi pas l'hybride Django+FastAPI** : DRF avec des async views (Django 5.x) couvre le besoin de performance. La latence de TOUPAC sera dominée par les requêtes DB et les appels réseau (OSRM, paiement mobile money), pas par le framework. Ajouter FastAPI crée un surcoût opérationnel sans gain utilisateur mesurable.

**Ce que dit le cahier des charges** : §7.2 mentionne "Node.js, NestJS, Laravel ou Go" — aucune de ces options n'est retenue. Le CdC liste des recommandations d'architecture, pas des contraintes. Django/Python est un meilleur fit pour les contraintes réelles (géospatial, multi-tenant, recrutabilité AO, budget startup).

---

### 1.2 Base de données

#### Option A — PostgreSQL 16 + PostGIS 3.4

| Critère | Évaluation |
|---|---|
| **Géospatial** | PostGIS est le standard mondial — index GIST, fonctions ST_*, géofencing, calculs de distance |
| **Performance** | Excellent — JSONB pour les champs flexibles, partitioning pour les tables de tracking, full-text search natif |
| **Multi-tenant** | Support natif des schémas PostgreSQL → isolation forte par tenant |
| **Maturité** | 30+ ans, le SGBD le plus fiable du marché open source |
| **Django** | GeoDjango + psycopg3 — intégration première classe |
| **TimescaleDB** | Extension PostgreSQL pour les séries temporelles (positions GPS) — même instance, pas de service séparé |

**Trade-off** : le meilleur choix pour un TMS géospatial — aucun compromis.

#### Option B — MySQL 8.x

| Critère | Évaluation |
|---|---|
| **Continuité** | C'est ce que Fleetbase utilisait (tables préfixées `fleetbase_`) |
| **Géospatial** | Fonctions spatiales basiques — pas de vrai index GIST, pas de ST_DWithin optimisé |
| **Multi-tenant** | Pas de schémas — isolation uniquement par `tenant_id` (row-level) |

**Trade-off** : familiarité Fleetbase mais clairement inférieur pour un TMS. On change de data model de toute façon — autant changer de SGBD.

#### Option C — PostgreSQL + TimescaleDB + InfluxDB (séparé pour le tracking)

| Critère | Évaluation |
|---|---|
| **Idée** | Base de données time-series dédiée pour les millions de points GPS |
| **Avantage** | Compression agressive, requêtes temporelles ultra-rapides |
| **Inconvénient** | Un service de plus à opérer, sync à gérer, complexité join cross-DB |

**Trade-off** : pertinent à grande échelle (>1000 véhicules trackés en continu), prématuré pour le MVP.

#### ➤ Recommandation : PostgreSQL 16 + PostGIS 3.4 (Option A)

TimescaleDB est une extension PostgreSQL activable à la demande (même instance), pas un service séparé. On l'active quand les volumes de tracking le justifient, sans migration.

**Ce que dit le CdC** : §7.3 mentionne "PostgreSQL, Redis, Elasticsearch, Timeseries DB" — PostgreSQL + PostGIS + (plus tard) TimescaleDB couvre les 3 premiers besoins dans un seul service.

---

### 1.3 Cache & sessions

#### Option A — Redis 7 (standalone)

| Critère | Évaluation |
|---|---|
| **Multi-usage** | Cache applicatif + sessions Django + broker Celery + pub/sub real-time + denylist JWT (pattern validé §4.19) |
| **Performance** | < 1ms latence locale — critique pour le denylist JWT vérifié à chaque requête |
| **Persistance** | AOF/RDB — survit aux redémarrages |
| **Budget** | 1 container = 4 fonctions (cache, sessions, broker, pub/sub). Imbattable en coût/valeur |

**Trade-off** : standard de l'industrie, pas de compromis.

#### Option B — Memcached

| Critère | Évaluation |
|---|---|
| **Simplicité** | Plus simple que Redis, mais pas de persistance, pas de pub/sub, pas de broker |
| **Limitation** | Ne peut pas servir de broker Celery ni de canal pub/sub — nécessite un service supplémentaire |

**Trade-off** : plus simple mais oblige à ajouter un broker séparé (RabbitMQ). Coûte plus cher en containers.

#### Option C — ValKey (fork Redis post-licence)

| Critère | Évaluation |
|---|---|
| **Licence** | BSD — pas de risque de changement de licence comme Redis SSPL |
| **Compatibilité** | Drop-in replacement de Redis |

**Trade-off** : choix défensif sur la licence. Pertinent si Redis change sa politique. Compatible avec tous les clients Redis.

#### ➤ Recommandation : Redis 7 (Option A), avec migration ValKey possible si besoin

1 container Redis = cache + sessions + broker Celery + pub/sub WebSocket + denylist JWT. Le pattern denylist JWT implémenté dans le Sprint 2 Fleetbase (§4.19 : claim `jti` + TTL = durée restante) est directement portable.

---

### 1.4 Queue & workers asynchrones

#### Option A — Celery 5 + Redis (broker)

| Critère | Évaluation |
|---|---|
| **Maturité** | Standard Django depuis 10+ ans, documentation abondante |
| **Use cases TOUPAC** | Sync offline batch (ControlEventProcessor), notifications (SMS/WhatsApp/push), génération factures, rapports PDF, appels VROOM/OSRM, webhooks |
| **Monitoring** | Flower (dashboard web) — debug en production |
| **Scheduled tasks** | Celery Beat — remplace cron pour les tâches périodiques (purge denylist, rapports quotidiens) |
| **Retry** | Retry automatique avec backoff exponentiel — critique pour les appels mobile money (timeout fréquents en AO) |

**Trade-off** : complexité de configuration initiale, mais la flexibilité est nécessaire pour les 6+ types de jobs asynchrones de TOUPAC.

#### Option B — Django-Q2

| Critère | Évaluation |
|---|---|
| **Simplicité** | Tout dans Django, broker optionnel (peut utiliser la DB comme broker) |
| **Limitation** | Moins de features que Celery (pas de canvas/chord, monitoring basique) |
| **Risque** | Projet plus petit, communauté plus réduite |

**Trade-off** : plus simple au départ, mais atteint ses limites quand les workflows deviennent complexes (ex : "appeler VROOM → attendre → dispatcher → notifier chauffeur → notifier client").

#### Option C — Dramatiq

| Critère | Évaluation |
|---|---|
| **API** | Plus propre que Celery (moins de magie, plus explicite) |
| **Perf** | Légèrement meilleur que Celery |
| **Communauté** | Plus petite, moins de plugins, moins de docs |
| **Recrutabilité** | Peu connu en AO |

**Trade-off** : meilleure DX mais écosystème plus restreint.

#### ➤ Recommandation : Celery 5 + Redis broker (Option A)

Le `ControlEventProcessor` (481 lignes dans le Sprint 2, dispatch de 10 `event_type`) devient un ensemble de Celery tasks avec retry. Le retry avec backoff exponentiel est critique pour les intégrations mobile money (PayDunya, CinetPay) où les timeouts réseau sont fréquents en Afrique de l'Ouest.

---

### 1.5 WebSocket & temps réel

#### Option A — Django Channels + Redis (backend unique)

| Critère | Évaluation |
|---|---|
| **Intégration** | Natif Django, protocole ASGI, même codebase |
| **Use cases** | Notifications dispatcher, updates statut commandes, chat dispatcher↔chauffeur |
| **Scaling** | Redis comme channel layer — scale horizontalement |
| **Limitation** | Pas conçu pour du tracking GPS haute fréquence (1 position/seconde × 500 véhicules) |

**Trade-off** : parfait pour les notifications UI, insuffisant pour le tracking GPS massif.

#### Option B — Centrifugo (microservice dédié)

| Critère | Évaluation |
|---|---|
| **Performance** | Conçu pour des millions de connexions concurrentes |
| **Protocole** | WebSocket + SSE + HTTP streaming |
| **Inconvénient** | Un service Go séparé à opérer, protocole propre à apprendre |

**Trade-off** : overkill au départ, pertinent à grande échelle.

#### Option C — Traccar (GPS) + Django Channels (notifications)

| Critère | Évaluation |
|---|---|
| **Traccar** | Serveur de tracking GPS spécialisé — protocoles 200+ devices GPS, WebSocket natif, API REST, stockage positions, géofencing, alertes |
| **Django Channels** | Uniquement pour les notifications UI (statut commandes, alertes dispatcher, chat) |
| **Séparation** | Chaque service fait ce qu'il sait faire — pas de réinvention |

**Trade-off** : 2 services pour le temps réel, mais chacun est spécialisé et évite de réinventer un tracker GPS.

#### ➤ Recommandation : Traccar 6 (GPS) + Django Channels (notifications UI) — Option C

Traccar est déjà identifié dans l'étude initiale comme brique réutilisable. Il gère nativement les protocoles de 200+ types de trackers GPS, le stockage des positions, les géofences, et expose un WebSocket pour le suivi en temps réel. Réimplémenter tout ça dans Django Channels serait des mois de travail sans valeur ajoutée.

Django Channels couvre le reste : notifications push vers la console web dispatcher, updates de statut en temps réel, chat opérationnel.

---

### 1.6 Admin panel / Console web

#### Option A — Django Admin + django-unfold (MVP)

| Critère | Évaluation |
|---|---|
| **Time to market** | Quelques jours pour un back-office CRUD complet avec filtres, recherche, export |
| **django-unfold** | Habillage Tailwind moderne de Django Admin — responsive, sidebar personnalisable, widgets dashboard |
| **Limitation** | Pas d'UX rich (drag-and-drop dispatch, carte temps réel, Kanban) |
| **Coût** | Gratuit (django-unfold est MIT) |

**Trade-off** : MVP fonctionnel très rapidement, mais UX limitée pour les écrans complexes.

#### Option B — Console React/Next.js (full custom)

| Critère | Évaluation |
|---|---|
| **UX** | Totalement sur-mesure — carte Mapbox/Leaflet, dispatch drag-and-drop, dashboards interactifs |
| **Time to market** | 3-4 mois supplémentaires avant un back-office équivalent à Django Admin |
| **Coût** | Significatif — frontend séparé = 1 dev frontend dédié minimum |
| **Stack** | React + TypeScript + Tailwind + Leaflet/Mapbox GL |

**Trade-off** : meilleure UX mais retarde le MVP de plusieurs mois.

#### Option C — Approche progressive (Django Admin → React)

| Critère | Évaluation |
|---|---|
| **Phase 1-2** | Django Admin + django-unfold pour tout le CRUD (organisations, véhicules, chauffeurs, commandes, lignes, tarifs) |
| **Phase 3+** | Écrans React embarqués progressivement pour les vues rich : carte temps réel, dispatch visuel, dashboard KPI |
| **Technique** | Django sert l'API DRF + les pages React en SPA montée sur un template Django |

**Trade-off** : le meilleur des deux mondes — MVP rapide, puis montée en UX progressive sans réécriture.

#### ➤ Recommandation : Approche progressive (Option C)

Django Admin pour les semaines 1-14 (Phases 1-2 de la roadmap). Console React progressive à partir de la Phase 3 pour les écrans qui nécessitent une UX complexe : carte temps réel, dispatching visuel, plan de sièges interactif, dashboards KPI.

Le cahier des charges §7.1 mentionne "React, Next.js, TypeScript, Tailwind" — c'est exactement ce qui sera utilisé pour la couche frontend progressive, mais **après** le MVP.

---

### 1.7 Authentification & IAM

#### Option A — Django auth natif + djangorestframework-simplejwt + django-guardian

| Critère | Évaluation |
|---|---|
| **Auth web** | Sessions Django classiques pour l'admin |
| **Auth API mobile** | JWT via simplejwt — access token court (30 min) + refresh token long (30 j), pattern identique à celui validé dans le Sprint 2 |
| **RBAC** | django-guardian pour les permissions objet-level (ex : "ce dispatcher ne voit que les commandes de son agence") |
| **Denylist JWT** | Natif dans simplejwt (blacklist app) — le pattern §4.19 (claim `jti` + denylist cache Redis) est déjà implémenté |
| **Multi-tenant** | Le tenant est dérivé du JWT (comme actuellement §OpenAPI : "company_uuid dérivé implicitement du token") |

**Trade-off** : léger, suffisant, directement compatible avec les patterns validés.

#### Option B — Keycloak

| Critère | Évaluation |
|---|---|
| **Puissance** | SSO, OAuth2, OIDC, fédération d'identité, MFA, social login |
| **Inconvénient** | Container JVM lourd (~512 Mo RAM minimum), configuration complexe, un service de plus à opérer |
| **Pertinence** | SSO/fédération utile si TOUPAC doit s'intégrer à des systèmes d'identité clients (ex: ERP) — pas nécessaire V1 |

**Trade-off** : surqualifié pour le MVP. Pertinent V2 si des clients entreprise demandent du SSO/SAML.

#### Option C — Auth0 / Clerk (SaaS)

| Critère | Évaluation |
|---|---|
| **Facilité** | Tout est géré — MFA, social login, webhooks |
| **Inconvénient** | Données d'auth hors cloud souverain SN — **violation de la contrainte**. Coût récurrent significatif |

**Trade-off** : incompatible avec la contrainte de cloud souverain sénégalais.

#### ➤ Recommandation : Django auth + simplejwt + django-guardian (Option A)

Le protocole JWT du Sprint 2 (access 30min/refresh 30j/denylist jti/rotation) est porté tel quel. L'auth contrôleur (email+password → JWT) et l'auth admin (session Django) couvrent les 2 familles d'utilisateurs.

Le PIN local offline (décision §3.2 du J5-STATE) reste côté app mobile React Native — aucun impact sur le backend.

---

### 1.8 Microservices externes (briques open source)

Ces services tournent dans leurs propres containers Docker, appelés par l'application Django via HTTP.

| Service | Rôle | Licence | Container | RAM estimée |
|---|---|---|---|---|
| **VROOM 1.14** | Optimisation de tournées (VRP solver) — dispatch intelligent multi-véhicules, multi-contraintes | BSD-2 | 1 | ~200 Mo |
| **OSRM** (backend) | Calcul d'itinéraires routiers sur données OpenStreetMap Afrique de l'Ouest | BSD-2 | 1 | ~1-2 Go (selon taille des données OSM) |
| **Traccar 6** | Serveur de tracking GPS — protocoles 200+ devices, WebSocket, API REST, géofences | Apache 2.0 | 1 (inclut sa DB H2 ou partage PostgreSQL) | ~256 Mo |

**Aucun de ces services n'est sous AGPL** — toutes les licences sont permissives (BSD, Apache).

**Ce que dit le CdC** : §6.3 mentionne "Microservices, Containers Docker" — les microservices TOUPAC sont ces 3 briques ciblées, pas une décomposition de l'application Django en 15 services.

**Ce que je recommande** : un monolithe modulaire Django (1 container) + 3 microservices externes spécialisés (VROOM, OSRM, Traccar) + Redis + PostgreSQL. Total : **6 containers**. C'est le minimum pour un TMS fonctionnel avec dispatch intelligent et tracking GPS.

---

### 1.9 Mobile

| Composant | Choix | Justification |
|---|---|---|
| **Framework** | React Native 0.75+ (New Architecture) | Cahier des charges implicite (Figma montre 3 apps), recrutabilité AO, single codebase iOS+Android |
| **Navigation** | React Navigation 7 | Standard de facto |
| **State management** | Zustand + React Query | Léger, adapté offline-first |
| **Offline storage** | WatermelonDB (SQLite) | DB locale avec sync — le protocole offline du Sprint 2 (batch events + idempotence `client_uuid`) s'y intègre nativement |
| **Cartographie** | react-native-maps + Mapbox | Mapbox pour la qualité des tuiles Afrique (meilleures que Google Maps dans les zones rurales AO) |
| **QR scanner** | react-native-vision-camera + ML Kit | Scan QR billet JWT RS256 (décision §3.1 du J5-STATE) |

**3 applications** (conformément au Figma) :
1. **App Contrôleur** — scan billets, manifeste, gestion embarquement, offline-first
2. **App Chauffeur** — missions, navigation, POD, statuts
3. **App Client** — réservation voyage, envoi colis, tracking, paiement mobile money

Les 3 apps partagent un monorepo React Native avec des packages communs (auth, offline sync, API client, composants UI).

---

### 1.10 Synthèse de la stack recommandée

```
┌─────────────────────────────────────────────────────────┐
│                    STACK TOUPAC v1                       │
├─────────────────────────────────────────────────────────┤
│  Backend         │  Django 5.x + DRF + GeoDjango        │
│  Langage         │  Python 3.12+                         │
│  Base de données │  PostgreSQL 16 + PostGIS 3.4          │
│  Cache / Broker  │  Redis 7                              │
│  Queue           │  Celery 5 + Celery Beat               │
│  WebSocket UI    │  Django Channels + Redis               │
│  Tracking GPS    │  Traccar 6 (Apache 2.0)               │
│  Route engine    │  OSRM (BSD-2) + données OSM AO        │
│  Dispatch engine │  VROOM 1.14 (BSD-2)                   │
│  Auth            │  Django auth + simplejwt + guardian    │
│  Admin panel     │  Django Admin + django-unfold (MVP)    │
│                  │  → Console React progressive (Phase 3) │
│  Mobile          │  React Native 0.75+ (monorepo × 3 apps)│
│  Mobile offline  │  WatermelonDB + batch sync protocol    │
│  Infra           │  Docker Compose (6 containers)         │
│  CI/CD           │  GitHub Actions                        │
│  Cloud           │  Cloud souverain sénégalais            │
│  Licence         │  MIT ou propriétaire — aucun AGPL      │
├─────────────────────────────────────────────────────────┤
│  CONTAINERS (6 total — budget startup)                  │
│  1. django-app (Django + Celery worker + Channels)      │
│  2. postgresql (+ PostGIS)                              │
│  3. redis                                               │
│  4. traccar                                             │
│  5. osrm                                               │
│  6. vroom                                               │
└─────────────────────────────────────────────────────────┘
```

#### Pourquoi 6 containers et pas 15

Le cahier des charges §6.3 mentionne "Microservices, Kubernetes, Event-driven architecture". Pour un MVP startup avec budget contraint et une équipe de 2-3 devs, Kubernetes est un surcoût d'opération disproportionné. Docker Compose sur un VPS cloud souverain (4-8 vCPU, 16-32 Go RAM) est suffisant pour les 12-18 premiers mois. La migration vers Kubernetes (ou Docker Swarm pour rester simple) se fait quand le trafic le justifie — pas avant.

Le monolithe modulaire Django (1 process, modules Python séparés par domaine) est le bon choix architectural pour une équipe de cette taille. Chaque module (voyage, colis, facturation, IAM, tracking) est un package Python avec ses propres models, views, serializers, tasks — mais ils partagent la même DB et le même process. Si un module doit être extrait en service séparé plus tard, la séparation en packages rend ça possible sans réécriture.

---

### 1.11 Matrice récapitulative des décisions

| Composant | Choix retenu | Alternatives écartées | Raison principale |
|---|---|---|---|
| Framework backend | Django 5 + DRF | Laravel 11, Django+FastAPI | GeoDjango + recrutabilité AO + admin natif |
| Base de données | PostgreSQL 16 + PostGIS | MySQL 8 | Géospatial natif, schémas multi-tenant |
| Cache | Redis 7 | Memcached, ValKey | 4 fonctions en 1 container |
| Queue | Celery 5 + Redis | Django-Q2, Dramatiq | Retry backoff pour mobile money, standard Django |
| WebSocket | Traccar (GPS) + Channels (UI) | Centrifugo, tout Channels | Spécialisation, pas de réinvention tracker |
| Admin | Django Admin + unfold → React | Filament, full React | MVP rapide, montée progressive |
| Auth | Django auth + simplejwt + guardian | Keycloak, Auth0 | Cloud souverain, patterns JWT portés du Sprint 2 |
| Mobile | React Native 0.75+ | Flutter, natif | Recrutabilité AO, monorepo 3 apps |
| Infra | Docker Compose (6 containers) | Kubernetes | Budget startup, équipe 2-3 devs |
-e 

---

# TOUPAC — Architecture Document v1.0

## Errata Section 1 (corrections validées)

**Correction 1 — Couverture géographique OSRM.** TOUPAC cible toute l'Afrique de l'Ouest (UEMOA + CEDEAO, 15 pays). Impact :
- OSRM doit charger l'extrait OSM `africa-west-latest.osm.pbf` (~1,2 Go compressé). RAM nécessaire en prod : 4-6 Go (contre ~1 Go pour le Sénégal seul). Le container OSRM est le plus gourmand de la stack.
- Les données clients ivoiriens, maliens, burkinabè, etc. sont hébergées sur le cloud souverain sénégalais. Point contractuel à traiter : les CGU TOUPAC doivent mentionner explicitement le pays d'hébergement, et chaque tenant doit consentir (conformité réglementations UEMOA sur les données personnelles).
- L'agrégateur mobile money doit couvrir les pays UEMOA+CEDEAO dès le V1 (Wave, Orange Money, MTN MoMo, Free Money selon le pays). Un agrégateur multi-pays type CinetPay ou PayDunya est indispensable — pas d'intégration provider par provider.

**Correction 2 — Split Container 1 en 3 process.** En production, le container Django se décompose en 3 services distincts (même image Docker, entrypoint différent) :

| Service | Entrypoint | Rôle | Scaling |
|---|---|---|---|
| `toupac-web` | `gunicorn --worker-class uvicorn.workers.UvicornWorker` | HTTP API + Django Admin | Horizontal (2-4 workers) |
| `toupac-worker` | `celery -A config worker` | Jobs asynchrones (sync offline, notifications, factures, VROOM) | Horizontal (1-2 workers) |
| `toupac-ws` | `daphne config.asgi:application` | WebSocket (Django Channels — notifications temps réel dispatcher) | 1 instance |

En dev, les 3 tournent dans un seul container Docker Compose. En staging/prod, 3 services séparés depuis la même image → total prod passe à **8 services** (3 Django + PostgreSQL + Redis + Traccar + OSRM + VROOM).

**Correction 3 — Console React repoussée.** Django Admin + django-unfold est le back-office de référence pour toute la V1 et probablement la V1.5. Pas de "Phase 3 React" dans la roadmap initiale. On réévalue quand un besoin UX spécifique (carte temps réel dispatcher, drag-and-drop dispatching) ne peut pas être servi par Django Admin.

---

## Section 2 — Schéma de base de données complet

### 2.0 Principes de conception

**Ce que dit le cahier des charges** : le CdC ne spécifie pas de schéma DB. Il décrit des modules fonctionnels (§4.1 à §4.12) traduits ici en tables.

**Ce que dit le travail Fleetbase** : 12 tables custom ont été créées et validées (Sprint 2, J5-STATE §2). 10 d'entre elles sont portées telles quelles. Les modèles Fleetbase natifs (Order, Payload, Entity, Waypoint) sont remplacés par des entités de première classe.

**Mes recommandations d'architecture DB** :

1. **Isolation multi-tenant par `tenant_id`** (row-level, pas schema-per-tenant). Chaque table métier porte un `tenant_id UUID NOT NULL` avec index. Les requêtes passent systématiquement par un middleware Django qui injecte le filtre tenant. Ce pattern est celui validé dans le test d'isolation 8/8 du Sprint 2 (§6.2 du J5-STATE), transposé de `company_uuid` à `tenant_id`.

2. **UUID v7 comme clé primaire** sur toutes les tables métier. UUID v7 (timestamp-ordered) plutôt que v4 : même compatibilité offline-first, mais les insertions sont séquentielles → pas de fragmentation d'index B-tree. Exception : `positions` utilise un `BIGINT` auto-increment (efficacité TimescaleDB).

3. **Montants en INTEGER** pour les devises XOF/XAF (franc CFA n'a pas de centimes). Pas de DECIMAL. Le champ s'appelle `amount_xof` partout — le suffixe `_xof` est une convention de lisibilité, la vraie devise est dans `tenants.currency`.

4. **PostGIS `geography(Point, 4326)`** pour toutes les coordonnées GPS. Pas de colonnes `latitude`/`longitude` séparées — leçon §4.16 du J5-STATE où `Place` Fleetbase n'avait pas ces colonnes et provoquait des `null` silencieux.

5. **Soft delete (`deleted_at`)** uniquement sur les entités réversibles (users, vehicles, drivers, passengers, orders). Pas sur les logs, events, positions.

6. **`created_by UUID`** sur les entités créées par un humain (orders, reservations, invoices). Pas sur les entités système (positions, geofence_events, notification_logs).

---

### 2.1 Mapping Fleetbase → TOUPAC (table de transition)

Ce tableau montre ce qui remplace quoi. Les 12 tables custom du Sprint 2 sont marquées ✅ PORT DIRECT.

| Concept | Fleetbase (ancien) | TOUPAC (nouveau) | Notes |
|---|---|---|---|
| Tenant | `companies` + `company_users` | `tenants` + `users.tenant_id` | Simplifié — pas de M2M user↔company V1 |
| Utilisateur | `users` (Fleetbase core) | `users` | Rôle en colonne ENUM, pas en table séparée V1 |
| Véhicule | `vehicles` | `vehicles` | Ajout type, PostGIS, documents |
| Chauffeur | `drivers` | `drivers` | Lien `user_id` préservé |
| Lieu | `places` (champ spatial `location`) | `places` (PostGIS `geography`) | Leçon §4.16 : plus de `latitude`/`longitude` fantômes |
| Zone | `zones` + `boundaries` | `zones` (PostGIS `polygon` inline) | Fusionné — 1 table au lieu de 2 |
| Voyage | `orders` (order_config=passenger_trip) | **`trips`** | Entité de première classe — plus de facade sur Order |
| Escales voyage | `waypoints` (via `payloads`) | **`route_stops`** + **`trip_stops`** | Route template + instance réelle séparés |
| Colis | `entities` (type=parcel) | **`parcels`** | Entité de première classe — plus de facade sur Entity |
| Commande colis | `orders` (logistique) | **`orders`** | Dédié colis, pas partagé avec voyage |
| Payload/container | `payloads` | ❌ Supprimé | Indirection inutile — les parcels sont liés directement aux orders |
| Config workflow | `order_configs` | ❌ Supprimé | Le workflow est dans le code Python (state machine), pas en DB |
| Passager | `passengers` (custom) | `passengers` | ✅ PORT DIRECT |
| Billet | `reservations` (custom) | `reservations` | ✅ PORT DIRECT + ajout `origin_stop_id`/`destination_stop_id` |
| Politique bagages | `luggage_policies` (custom) | `luggage_policies` | ✅ PORT DIRECT |
| Plan sièges | `seat_maps` (custom) | `seat_maps` | ✅ PORT DIRECT |
| Contrôleur | `controllers` (custom) | `controllers` | ✅ PORT DIRECT |
| Session contrôle | `control_sessions` (custom) | `control_sessions` | ✅ PORT DIRECT |
| Event offline | `control_events` (custom) | `control_events` | ✅ PORT DIRECT |
| Anomalie | `anomalies` (custom) | `anomalies` | ✅ PORT DIRECT |
| Incident | `incidents` (custom) | `incidents` | ✅ PORT DIRECT |
| Encaissement | `cash_entries` (custom) | `cash_entries` | ✅ PORT DIRECT |
| Audit RGPD | `passenger_access_log` (custom) | `passenger_access_log` | ✅ PORT DIRECT (renommé en snake_case Django) |

**Tables nouvelles** (n'existaient pas dans Fleetbase ni dans le Sprint 2) :
`vehicle_types`, `vehicle_documents`, `fleets`, `fleet_vehicles`, `routes`, `route_stops`, `schedules`, `trip_stops`, `delivery_tasks`, `proofs_of_delivery`, `price_lists`, `price_rules`, `invoices`, `invoice_lines`, `payments`, `positions`, `geofences`, `geofence_events`, `tracking_links`, `notification_templates`, `notification_logs`, `user_devices`, `api_credentials`, `audit_logs`.

---

### 2.2 Schéma détaillé par module

#### Module IAM (5 tables)

**`tenants`** — Racine multi-tenant. Une ligne = une compagnie de transport cliente de TOUPAC.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `name` | VARCHAR(200) | NOT NULL | Nom commercial |
| `slug` | VARCHAR(100) | UNIQUE | URL-safe, auto-généré |
| `country_code` | CHAR(2) | NOT NULL | ISO 3166-1 (SN, CI, ML, BF, GH...) |
| `currency` | CHAR(3) | NOT NULL, DEFAULT 'XOF' | ISO 4217 |
| `timezone` | VARCHAR(50) | NOT NULL, DEFAULT 'Africa/Dakar' | |
| `language` | CHAR(2) | NOT NULL, DEFAULT 'fr' | |
| `settings` | JSONB | DEFAULT '{}' | Préférences (branding, features toggles) |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'active' | active, suspended, trial |
| `subscription_plan` | VARCHAR(30) | | free, starter, pro, enterprise |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

**`users`** — Tous les utilisateurs de toutes les compagnies. Le rôle est en ENUM pour simplifier le RBAC V1.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | NULL uniquement pour les super-admins TOUPAC |
| `email` | VARCHAR(255) | UNIQUE | Login principal |
| `phone` | VARCHAR(20) | | Format E.164 (+221...) |
| `password_hash` | VARCHAR(255) | NOT NULL | Argon2id (Django default) |
| `first_name` | VARCHAR(100) | NOT NULL | |
| `last_name` | VARCHAR(100) | NOT NULL | |
| `role` | VARCHAR(20) | NOT NULL | superadmin, admin, dispatcher, agent, driver, controller, client |
| `is_active` | BOOLEAN | DEFAULT true | |
| `last_login_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |
| `deleted_at` | TIMESTAMPTZ | | Soft delete |

Index : `(tenant_id)`, `(tenant_id, role)`, `(email)` UNIQUE.

**`api_credentials`** — Clés API pour intégrations tierces (ERP, e-commerce).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `user_id` | UUID | FK users | Créateur |
| `name` | VARCHAR(100) | NOT NULL | Label descriptif |
| `key_prefix` | VARCHAR(12) | NOT NULL | Premiers chars affichés (tpk_live_abc...) |
| `key_hash` | VARCHAR(255) | NOT NULL | SHA-256 de la clé complète |
| `scopes` | JSONB | DEFAULT '[]' | Permissions API granulaires |
| `is_active` | BOOLEAN | DEFAULT true | |
| `expires_at` | TIMESTAMPTZ | | |
| `last_used_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`audit_logs`** — Trail d'audit pour conformité RGPD-like et traçabilité.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants | |
| `user_id` | UUID | FK users | |
| `action` | VARCHAR(50) | NOT NULL | create, update, delete, login, export, view_pii |
| `resource_type` | VARCHAR(50) | NOT NULL | Nom du modèle Django |
| `resource_id` | UUID | | |
| `changes` | JSONB | | Diff avant/après pour les updates |
| `ip_address` | INET | | Type PostgreSQL natif |
| `user_agent` | VARCHAR(500) | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`user_devices`** — Tokens push notification (Firebase Cloud Messaging).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `user_id` | UUID | FK users, NOT NULL | |
| `platform` | VARCHAR(10) | NOT NULL | android, ios |
| `push_token` | VARCHAR(500) | NOT NULL | FCM token |
| `device_model` | VARCHAR(100) | | |
| `app_version` | VARCHAR(20) | | |
| `is_active` | BOOLEAN | DEFAULT true | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

---

#### Module Flotte (6 tables)

**`vehicle_types`** — Catégories de véhicules (bus 45 places, minibus 15 places, van 8 places...).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | "Bus 45 places", "Sprinter 15" |
| `default_capacity` | INTEGER | NOT NULL | |
| `fuel_type` | VARCHAR(20) | | diesel, essence, electric |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`vehicles`**

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `vehicle_type_id` | UUID | FK vehicle_types | |
| `plate_number` | VARCHAR(20) | NOT NULL | Unique par tenant (index partiel) |
| `make` | VARCHAR(50) | | Mercedes, Toyota... |
| `model` | VARCHAR(50) | | Sprinter, HiAce... |
| `year` | SMALLINT | | |
| `capacity` | INTEGER | NOT NULL | Peut surcharger vehicle_type |
| `vin` | VARCHAR(17) | | Numéro de châssis |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'available' | available, in_use, maintenance, decommissioned |
| `location` | GEOGRAPHY(Point, 4326) | | Dernière position connue |
| `traccar_device_id` | VARCHAR(50) | | ID dans Traccar pour le lien GPS |
| `metadata` | JSONB | DEFAULT '{}' | Champs custom par tenant |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |
| `deleted_at` | TIMESTAMPTZ | | |

Index : `(tenant_id)`, `(tenant_id, plate_number)` UNIQUE WHERE deleted_at IS NULL, GIST sur `location`.

**`drivers`**

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `user_id` | UUID | FK users, UNIQUE | 1:1 avec un user de role=driver |
| `license_number` | VARCHAR(50) | | |
| `license_class` | VARCHAR(10) | | A, B, C, D, E... |
| `license_expiry` | DATE | | Alerte automatique 30j avant |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'available' | available, on_trip, off_duty |
| `score` | DECIMAL(5,2) | DEFAULT 100.00 | Score de performance 0-100 |
| `last_known_location` | GEOGRAPHY(Point, 4326) | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |
| `deleted_at` | TIMESTAMPTZ | | |

**`vehicle_documents`** — Assurances, visites techniques, cartes grises.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `vehicle_id` | UUID | FK vehicles, NOT NULL | |
| `type` | VARCHAR(30) | NOT NULL | insurance, registration, inspection, transport_permit |
| `document_number` | VARCHAR(100) | | |
| `issue_date` | DATE | | |
| `expiry_date` | DATE | | Alerte automatique 30j avant |
| `file_url` | VARCHAR(500) | | S3-compatible object storage |
| `status` | VARCHAR(20) | DEFAULT 'valid' | valid, expired, pending_renewal |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`fleets`** — Regroupement logique de véhicules (parc Dakar, parc Bamako...).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | |
| `zone` | VARCHAR(100) | | Couverture géographique |
| `manager_id` | UUID | FK users | Responsable du parc |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`fleet_vehicles`** — M2M fleets ↔ vehicles.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `fleet_id` | UUID | FK fleets, NOT NULL | |
| `vehicle_id` | UUID | FK vehicles, NOT NULL | |
| `assigned_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(fleet_id, vehicle_id)`.

---

#### Module Géographie (2 tables)

**`places`** — Points d'intérêt : gares routières, dépôts, adresses clients.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants | NULL = place partagée (gare publique) |
| `name` | VARCHAR(200) | NOT NULL | "Gare routière Pompiers, Bamako" |
| `address` | VARCHAR(500) | | Adresse textuelle |
| `city` | VARCHAR(100) | | |
| `country_code` | CHAR(2) | | |
| `location` | GEOGRAPHY(Point, 4326) | NOT NULL | PostGIS — remplace le piège §4.16 |
| `type` | VARCHAR(30) | | station, depot, hub, client_address, other |
| `metadata` | JSONB | DEFAULT '{}' | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index GIST sur `location`.

**`zones`** — Zones de service, géofences, zones tarifaires.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | |
| `type` | VARCHAR(20) | NOT NULL | service, geofence, tariff |
| `boundary` | GEOGRAPHY(Polygon, 4326) | NOT NULL | Polygone PostGIS |
| `is_active` | BOOLEAN | DEFAULT true | |
| `alert_on_exit` | BOOLEAN | DEFAULT false | Géofencing |
| `metadata` | JSONB | DEFAULT '{}' | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index GIST sur `boundary`.

---

#### Module Voyage — Passagers (14 tables)

C'est le cœur du domaine TOUPAC et le module le plus complexe. Les 10 tables custom du Sprint 2 sont portées ici avec des ajouts structurants : `routes`, `route_stops`, `schedules`, `trip_stops`.

**`routes`** — Lignes de transport régulières (concept absent de Fleetbase).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(200) | NOT NULL | "Dakar → Bamako" |
| `code` | VARCHAR(20) | NOT NULL | "DKR-BKO" — unique par tenant |
| `origin_place_id` | UUID | FK places, NOT NULL | Gare de départ |
| `destination_place_id` | UUID | FK places, NOT NULL | Gare d'arrivée |
| `distance_km` | INTEGER | | Calculé via OSRM |
| `duration_minutes` | INTEGER | | Estimé via OSRM |
| `luggage_policy_id` | UUID | FK luggage_policies | Politique par défaut pour cette ligne |
| `is_active` | BOOLEAN | DEFAULT true | |
| `metadata` | JSONB | DEFAULT '{}' | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(tenant_id, code)`.

**`route_stops`** — Escales ordonnées sur une ligne (remplace les Waypoints Fleetbase).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `route_id` | UUID | FK routes, NOT NULL | |
| `place_id` | UUID | FK places, NOT NULL | |
| `stop_order` | SMALLINT | NOT NULL | 0 = départ, N = arrivée |
| `offset_minutes` | INTEGER | NOT NULL, DEFAULT 0 | Minutes depuis le départ théorique |
| `is_boarding` | BOOLEAN | DEFAULT true | Montée autorisée |
| `is_alighting` | BOOLEAN | DEFAULT true | Descente autorisée |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(route_id, stop_order)`.

**`schedules`** — Horaires récurrents ("départ tous les jours à 8h et 18h").

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `route_id` | UUID | FK routes, NOT NULL | |
| `departure_time` | TIME | NOT NULL | 08:00, 18:00... |
| `days_of_week` | SMALLINT[] | NOT NULL | {1,2,3,4,5} = lun-ven, PostgreSQL array |
| `default_vehicle_type_id` | UUID | FK vehicle_types | Type de véhicule par défaut |
| `default_price_xof` | INTEGER | | Tarif de base |
| `is_active` | BOOLEAN | DEFAULT true | |
| `valid_from` | DATE | | |
| `valid_until` | DATE | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`seat_maps`** — Plans de sièges par type de véhicule. ✅ PORT DIRECT du Sprint 2.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `vehicle_type_id` | UUID | FK vehicle_types | |
| `name` | VARCHAR(100) | NOT NULL | "Bus 45 standard" |
| `total_seats` | INTEGER | NOT NULL | |
| `layout` | JSONB | NOT NULL | `{"rows": 11, "cols": 4, "seats": [{"label":"A1","row":1,"col":1,"type":"window"}, ...]}` |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`trips`** — Voyages physiques. Remplace `orders` avec `order_config=passenger_trip`. C'est LA table centrale du module voyage.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `route_id` | UUID | FK routes, NOT NULL | |
| `schedule_id` | UUID | FK schedules | Null si voyage exceptionnel |
| `vehicle_id` | UUID | FK vehicles | |
| `driver_id` | UUID | FK drivers | |
| `seat_map_id` | UUID | FK seat_maps | Plan de sièges utilisé |
| `internal_id` | VARCHAR(20) | NOT NULL | "VYG-2026-0847" — auto-généré, unique par tenant |
| `departure_date` | DATE | NOT NULL | |
| `scheduled_at` | TIMESTAMPTZ | NOT NULL | Date+heure de départ prévue |
| `actual_departure_at` | TIMESTAMPTZ | | |
| `actual_arrival_at` | TIMESTAMPTZ | | |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'scheduled' | scheduled, preparing, boarding, in_transit, at_stop, arriving, completed, cancelled |
| `total_seats` | INTEGER | NOT NULL | Copié du seat_map au moment de la création |
| `booked_seats` | INTEGER | NOT NULL, DEFAULT 0 | Dénormalisé, mis à jour par trigger |
| `summary` | JSONB | | Résumé de clôture (stats passagers, colis, cash, anomalies) |
| `created_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

Index : `(tenant_id, departure_date)`, `(tenant_id, internal_id)` UNIQUE, `(tenant_id, status)`.

Le flow de statuts `scheduled → preparing → boarding → in_transit → at_stop → arriving → completed` reprend exactement le flow linéaire validé dans le Sprint 2 (§4.9 du J5-STATE : "PAS de cycles bidirectionnels → stack overflow").

**`trip_stops`** — Instance réelle des escales pour un voyage donné (heures réelles d'arrivée/départ).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `trip_id` | UUID | FK trips, NOT NULL | |
| `route_stop_id` | UUID | FK route_stops, NOT NULL | Lien vers le template |
| `place_id` | UUID | FK places, NOT NULL | Dénormalisé pour perf |
| `stop_order` | SMALLINT | NOT NULL | |
| `eta` | TIMESTAMPTZ | | Heure d'arrivée estimée (OSRM) |
| `ata` | TIMESTAMPTZ | | Heure d'arrivée réelle |
| `atd` | TIMESTAMPTZ | | Heure de départ réelle |
| `status` | VARCHAR(20) | DEFAULT 'pending' | pending, arrived, departed, skipped |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`passengers`** — ✅ PORT DIRECT du Sprint 2.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `first_name` | VARCHAR(100) | NOT NULL | |
| `last_name` | VARCHAR(100) | NOT NULL | |
| `phone` | VARCHAR(20) | NOT NULL | |
| `email` | VARCHAR(255) | | |
| `id_type` | VARCHAR(30) | | cni, passport, carte_consulaire, cedeao_card |
| `id_number` | VARCHAR(50) | | Données sensibles — accès audité |
| `id_photo_url` | VARCHAR(500) | | Données sensibles — accès audité |
| `nationality` | CHAR(2) | | |
| `date_of_birth` | DATE | | |
| `emergency_contact_name` | VARCHAR(100) | | |
| `emergency_contact_phone` | VARCHAR(20) | | |
| `metadata` | JSONB | DEFAULT '{}' | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |
| `deleted_at` | TIMESTAMPTZ | | RGPD : droit à l'effacement |

**`reservations`** — Billets. ✅ PORT DIRECT du Sprint 2, enrichi de `origin_stop_id`/`destination_stop_id`.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `trip_id` | UUID | FK trips, NOT NULL | |
| `passenger_id` | UUID | FK passengers, NOT NULL | |
| `seat_label` | VARCHAR(10) | | "A12", "B4" |
| `origin_stop_id` | UUID | FK route_stops | Montée (null = départ) |
| `destination_stop_id` | UUID | FK route_stops | Descente (null = terminus) |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'booked' | booked, checked_in, boarded, no_show, refused, cancelled |
| `amount_xof` | INTEGER | NOT NULL | |
| `payment_method` | VARCHAR(20) | | online, counter, onboard_cash |
| `payment_ref` | VARCHAR(100) | | Réf. transaction mobile money |
| `qr_code_jwt` | TEXT | | JWT RS256 signé (§3.1 J5-STATE) |
| `boarded_by` | UUID | FK controllers | |
| `boarded_at` | TIMESTAMPTZ | | |
| `boarding_method` | VARCHAR(20) | | qr_scan, manual, offline |
| `special_case_reason` | VARCHAR(200) | | |
| `refusal_reason` | VARCHAR(200) | | |
| `luggage` | JSONB | | `{"pieces": 2, "weight_kg": 25, "excess_paid_xof": 5000}` |
| `sales_channel` | VARCHAR(20) | DEFAULT 'counter' | counter, app_client, onboard, api |
| `created_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

Index : `(trip_id, seat_label)` UNIQUE WHERE status NOT IN ('cancelled', 'refused'), `(tenant_id, trip_id)`, `(passenger_id)`.

**`luggage_policies`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | |
| `included_kg` | INTEGER | NOT NULL | Franchise incluse |
| `max_kg` | INTEGER | NOT NULL | |
| `excess_price_per_kg_xof` | INTEGER | NOT NULL | |
| `max_pieces` | INTEGER | | |
| `restricted_items` | JSONB | | Liste d'items interdits |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`controllers`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `user_id` | UUID | FK users, UNIQUE | 1:1 avec un user de role=controller |
| `matricule` | VARCHAR(20) | NOT NULL | "CH-0421" — unique par tenant |
| `agency` | VARCHAR(100) | | Agence de rattachement |
| `score_conformity` | DECIMAL(5,2) | DEFAULT 100.00 | |
| `total_trips` | INTEGER | DEFAULT 0 | |
| `status` | VARCHAR(20) | DEFAULT 'active' | active, inactive, suspended |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(tenant_id, matricule)`.

**`control_sessions`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `trip_id` | UUID | FK trips, NOT NULL | |
| `controller_id` | UUID | FK controllers, NOT NULL | |
| `device_id` | VARCHAR(100) | NOT NULL | |
| `device_info` | JSONB | | OS, version app, modèle |
| `opened_at` | TIMESTAMPTZ | NOT NULL | |
| `closed_at` | TIMESTAMPTZ | | |
| `sync_state` | VARCHAR(20) | DEFAULT 'draft' | draft, syncing, synced, failed |
| `last_sync_at` | TIMESTAMPTZ | | |
| `close_summary` | JSONB | | Stats de clôture (CloseTripRequest) |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`control_events`** — ✅ PORT DIRECT. Queue offline avec idempotence `client_uuid`.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `session_id` | UUID | FK control_sessions, NOT NULL | |
| `client_uuid` | UUID | NOT NULL | Idempotence — UNIQUE par tenant |
| `event_type` | VARCHAR(30) | NOT NULL | reservation_board, reservation_refuse, reservation_special_case, parcel_verify, parcel_refuse, onboard_sale, anomaly_create, anomaly_resolve, incident_create, activity_transition |
| `target_type` | VARCHAR(30) | | reservation, parcel, anomaly, incident, trip |
| `target_id` | UUID | | |
| `payload` | JSONB | NOT NULL | Données spécifiques au type d'event |
| `status` | VARCHAR(20) | DEFAULT 'pending' | pending, processed, rejected |
| `rejection_reason` | VARCHAR(100) | | |
| `gps_location` | GEOGRAPHY(Point, 4326) | | |
| `gps_accuracy_m` | INTEGER | | |
| `created_at_local` | TIMESTAMPTZ | NOT NULL | Horodatage côté device |
| `processed_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | Horodatage serveur |

Index unique : `(tenant_id, client_uuid)`.

**`anomalies`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `session_id` | UUID | FK control_sessions | |
| `event_id` | UUID | FK control_events | Event déclencheur (auto-anomalies) |
| `type` | VARCHAR(30) | NOT NULL | duplicate_scan, seat_conflict, parcel_non_conform, expired_ticket, wrong_trip, other |
| `severity` | VARCHAR(10) | NOT NULL | low, moderate, critical |
| `status` | VARCHAR(20) | DEFAULT 'to_treat' | to_treat, in_progress, resolved, ignored |
| `title` | VARCHAR(200) | NOT NULL | |
| `description` | TEXT | | |
| `target_type` | VARCHAR(30) | | |
| `target_id` | UUID | | |
| `evidence_urls` | JSONB | | URLs photos/documents |
| `resolved_at` | TIMESTAMPTZ | | |
| `resolution_notes` | TEXT | | |
| `resolved_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`incidents`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `session_id` | UUID | FK control_sessions | |
| `trip_id` | UUID | FK trips, NOT NULL | |
| `reporter_id` | UUID | FK users, NOT NULL | |
| `type` | VARCHAR(20) | NOT NULL | luggage, behavior, safety, breakdown, other |
| `severity` | VARCHAR(10) | NOT NULL | low, moderate, critical |
| `title` | VARCHAR(200) | NOT NULL | |
| `description` | TEXT | | |
| `photos_urls` | JSONB | | |
| `gps_location` | GEOGRAPHY(Point, 4326) | | |
| `gps_address` | VARCHAR(300) | | Géocodage inverse |
| `status` | VARCHAR(20) | DEFAULT 'reported' | reported, notified, in_progress, resolved |
| `dispatcher_notified` | BOOLEAN | DEFAULT false | |
| `dispatcher_notified_at` | TIMESTAMPTZ | | |
| `resolved_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`cash_entries`** — ✅ PORT DIRECT.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `session_id` | UUID | FK control_sessions, NOT NULL | |
| `reservation_id` | UUID | FK reservations | |
| `amount_xof` | INTEGER | NOT NULL | |
| `reason` | VARCHAR(30) | NOT NULL | onboard_sale, luggage_excess, penalty, other |
| `collected_by` | UUID | FK controllers, NOT NULL | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`passenger_access_log`** — ✅ PORT DIRECT. Audit RGPD des accès aux CNI.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `passenger_id` | UUID | FK passengers, NOT NULL | |
| `user_id` | UUID | FK users | Null si accès système |
| `context` | VARCHAR(30) | NOT NULL | boarding_check, admin_view, export |
| `ip_address` | INET | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

---

#### Module Colis — Logistique (4 tables)

**`orders`** — Commandes de livraison de colis (ne pas confondre avec `fleetbase_orders`).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `internal_id` | VARCHAR(20) | NOT NULL | "CMD-2026-0123" — unique par tenant |
| `customer_id` | UUID | FK users | Client final ou entreprise |
| `customer_name` | VARCHAR(200) | | Si client non-inscrit |
| `customer_phone` | VARCHAR(20) | | |
| `pickup_place_id` | UUID | FK places, NOT NULL | |
| `dropoff_place_id` | UUID | FK places, NOT NULL | |
| `pickup_window_start` | TIMESTAMPTZ | | |
| `pickup_window_end` | TIMESTAMPTZ | | |
| `delivery_window_start` | TIMESTAMPTZ | | |
| `delivery_window_end` | TIMESTAMPTZ | | |
| `priority` | VARCHAR(10) | DEFAULT 'standard' | standard, express, urgent |
| `status` | VARCHAR(20) | DEFAULT 'draft' | draft, confirmed, dispatched, picked_up, in_transit, delivered, failed, cancelled |
| `total_amount_xof` | INTEGER | | |
| `payment_status` | VARCHAR(20) | DEFAULT 'pending' | pending, paid, refunded |
| `instructions` | TEXT | | Instructions spéciales |
| `metadata` | JSONB | DEFAULT '{}' | |
| `created_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |
| `deleted_at` | TIMESTAMPTZ | | |

**`parcels`** — Colis individuels au sein d'une commande. Remplace `entities` avec `type=parcel`.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `order_id` | UUID | FK orders, NOT NULL | |
| `tracking_number` | VARCHAR(20) | NOT NULL | "TPC-xxxxxxxxxx" — unique global |
| `description` | VARCHAR(500) | | |
| `weight_kg` | DECIMAL(8,2) | | |
| `length_cm` | DECIMAL(6,1) | | |
| `width_cm` | DECIMAL(6,1) | | |
| `height_cm` | DECIMAL(6,1) | | |
| `category` | VARCHAR(20) | DEFAULT 'standard' | standard, fragile, perishable, hazardous |
| `declared_value_xof` | INTEGER | | Pour assurance |
| `status` | VARCHAR(20) | DEFAULT 'created' | created, picked_up, in_transit, at_hub, out_for_delivery, delivered, returned |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(tracking_number)`.

**`delivery_tasks`** — Tâches de pickup/delivery assignées à un chauffeur.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `order_id` | UUID | FK orders, NOT NULL | |
| `driver_id` | UUID | FK drivers | |
| `vehicle_id` | UUID | FK vehicles | |
| `type` | VARCHAR(10) | NOT NULL | pickup, delivery |
| `status` | VARCHAR(20) | DEFAULT 'pending' | pending, assigned, accepted, en_route, arrived, completed, failed |
| `sequence_order` | INTEGER | | Ordre dans la tournée (VROOM) |
| `place_id` | UUID | FK places, NOT NULL | Lieu de la tâche |
| `estimated_arrival` | TIMESTAMPTZ | | ETA calculé par OSRM |
| `actual_arrival` | TIMESTAMPTZ | | |
| `completed_at` | TIMESTAMPTZ | | |
| `failure_reason` | VARCHAR(200) | | |
| `route_geometry` | GEOGRAPHY(LineString, 4326) | | Polyline OSRM |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

**`proofs_of_delivery`** — Preuves de livraison (CdC §4.9).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `delivery_task_id` | UUID | FK delivery_tasks, NOT NULL | |
| `type` | VARCHAR(20) | NOT NULL | signature, photo, qr_scan, otp |
| `signature_url` | VARCHAR(500) | | Image de la signature |
| `photos_urls` | JSONB | | `["url1", "url2"]` |
| `otp_code` | VARCHAR(10) | | Code OTP validé |
| `recipient_name` | VARCHAR(100) | | |
| `recipient_phone` | VARCHAR(20) | | |
| `notes` | TEXT | | |
| `gps_location` | GEOGRAPHY(Point, 4326) | | Lieu de livraison réel |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

---

#### Module Facturation (4 tables)

**`price_lists`** — Grilles tarifaires par tenant (une pour le voyage, une pour les colis).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | "Tarifs Voyage 2026", "Tarifs Colis Zone Ouest" |
| `type` | VARCHAR(10) | NOT NULL | voyage, colis |
| `currency` | CHAR(3) | NOT NULL, DEFAULT 'XOF' | |
| `is_active` | BOOLEAN | DEFAULT true | |
| `valid_from` | DATE | | |
| `valid_until` | DATE | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`price_rules`** — Règles tarifaires au sein d'une grille.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `price_list_id` | UUID | FK price_lists, NOT NULL | |
| `route_id` | UUID | FK routes | Pour voyage : tarif fixe par trajet |
| `origin_zone_id` | UUID | FK zones | Pour colis : tarif par zone |
| `destination_zone_id` | UUID | FK zones | |
| `calculation_method` | VARCHAR(20) | NOT NULL | fixed, per_km, per_kg, per_zone |
| `base_amount_xof` | INTEGER | NOT NULL | |
| `rate_per_unit` | DECIMAL(10,2) | | XOF par km ou par kg |
| `min_amount_xof` | INTEGER | | Plancher |
| `max_amount_xof` | INTEGER | | Plafond |
| `conditions` | JSONB | DEFAULT '{}' | Conditions d'application |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`invoices`** — Factures générées.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `invoice_number` | VARCHAR(20) | NOT NULL | "FAC-2026-0047" — unique par tenant |
| `customer_id` | UUID | | Peut être un user, un passager, ou une entreprise |
| `customer_type` | VARCHAR(20) | | user, passenger, external |
| `customer_name` | VARCHAR(200) | NOT NULL | Dénormalisé pour l'affichage |
| `issue_date` | DATE | NOT NULL | |
| `due_date` | DATE | | |
| `subtotal_xof` | INTEGER | NOT NULL | |
| `tax_xof` | INTEGER | NOT NULL, DEFAULT 0 | TVA/taxe locale |
| `total_xof` | INTEGER | NOT NULL | |
| `currency` | CHAR(3) | DEFAULT 'XOF' | |
| `status` | VARCHAR(20) | DEFAULT 'draft' | draft, sent, paid, overdue, cancelled |
| `paid_at` | TIMESTAMPTZ | | |
| `metadata` | JSONB | DEFAULT '{}' | Infos fiscales par pays |
| `created_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |
| `updated_at` | TIMESTAMPTZ | NOT NULL | |

**`invoice_lines`** — Lignes de facture.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `invoice_id` | UUID | FK invoices, NOT NULL | |
| `description` | VARCHAR(500) | NOT NULL | |
| `reference_type` | VARCHAR(20) | | reservation, order, extra |
| `reference_id` | UUID | | |
| `quantity` | INTEGER | NOT NULL, DEFAULT 1 | |
| `unit_price_xof` | INTEGER | NOT NULL | |
| `amount_xof` | INTEGER | NOT NULL | |
| `tax_xof` | INTEGER | DEFAULT 0 | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`payments`** — Transactions de paiement (mobile money, cash, virement).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `invoice_id` | UUID | FK invoices | |
| `reservation_id` | UUID | FK reservations | Paiement direct billet |
| `order_id` | UUID | FK orders | Paiement direct colis |
| `provider` | VARCHAR(20) | NOT NULL | wave, orange_money, free_money, mtn_momo, cash, bank_transfer |
| `provider_tx_id` | VARCHAR(100) | | ID transaction chez le provider |
| `amount_xof` | INTEGER | NOT NULL | |
| `currency` | CHAR(3) | DEFAULT 'XOF' | |
| `status` | VARCHAR(20) | DEFAULT 'initiated' | initiated, pending, success, failed, refunded |
| `failure_reason` | VARCHAR(300) | | |
| `provider_response` | JSONB | | Réponse brute du provider (debug) |
| `initiated_at` | TIMESTAMPTZ | NOT NULL | |
| `completed_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

---

#### Module Tracking (4 tables)

**`positions`** — Positions GPS des véhicules. Table la plus volumineuse — candidate TimescaleDB.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | BIGINT | PK, auto-increment | Pas UUID — perf TimescaleDB |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `vehicle_id` | UUID | FK vehicles, NOT NULL | |
| `driver_id` | UUID | FK drivers | |
| `location` | GEOGRAPHY(Point, 4326) | NOT NULL | |
| `speed_kmh` | DECIMAL(6,1) | | |
| `heading` | DECIMAL(5,1) | | Azimut 0-360 |
| `accuracy_m` | SMALLINT | | |
| `altitude_m` | SMALLINT | | |
| `source` | VARCHAR(10) | DEFAULT 'traccar' | traccar, driver_app, manual |
| `recorded_at` | TIMESTAMPTZ | NOT NULL | Clé de partitionnement TimescaleDB |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index : `(vehicle_id, recorded_at DESC)`, GIST sur `location`. Candidate `SELECT create_hypertable('positions', 'recorded_at')` quand les volumes le justifient.

**`geofences`** — Zones surveillées (dépôts, hubs, sites clients, zones interdites).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `name` | VARCHAR(100) | NOT NULL | |
| `type` | VARCHAR(20) | NOT NULL | depot, hub, client_site, restricted, country_border |
| `boundary` | GEOGRAPHY(Polygon, 4326) | NOT NULL | |
| `is_active` | BOOLEAN | DEFAULT true | |
| `alert_rules` | JSONB | DEFAULT '{}' | `{"on_exit": true, "on_enter": false, "dwell_minutes": 30}` |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`geofence_events`** — Événements entrée/sortie/stationnement.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `geofence_id` | UUID | FK geofences, NOT NULL | |
| `vehicle_id` | UUID | FK vehicles, NOT NULL | |
| `event_type` | VARCHAR(10) | NOT NULL | enter, exit, dwell |
| `event_at` | TIMESTAMPTZ | NOT NULL | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

**`tracking_links`** — URLs publiques de suivi (client final suit son colis/voyage).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `token` | VARCHAR(32) | NOT NULL, UNIQUE | Token aléatoire URL-safe |
| `resource_type` | VARCHAR(10) | NOT NULL | order, trip |
| `resource_id` | UUID | NOT NULL | |
| `expires_at` | TIMESTAMPTZ | NOT NULL | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

---

#### Module Notifications (2 tables)

**`notification_templates`** — Modèles de messages par type d'événement et canal.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants | NULL = template système par défaut |
| `event_type` | VARCHAR(50) | NOT NULL | reservation_confirmed, trip_departure_reminder, delivery_complete, payment_received... |
| `channel` | VARCHAR(10) | NOT NULL | sms, whatsapp, push, email |
| `language` | CHAR(2) | DEFAULT 'fr' | |
| `subject` | VARCHAR(200) | | Pour email uniquement |
| `template_body` | TEXT | NOT NULL | Avec variables `{{passenger_name}}`, `{{trip_route}}`... |
| `is_active` | BOOLEAN | DEFAULT true | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(tenant_id, event_type, channel, language)`.

**`notification_logs`** — Historique des notifications envoyées.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants, NOT NULL | |
| `user_id` | UUID | FK users | Destinataire |
| `channel` | VARCHAR(10) | NOT NULL | |
| `recipient` | VARCHAR(100) | NOT NULL | Numéro, email, device token |
| `event_type` | VARCHAR(50) | NOT NULL | |
| `content` | TEXT | | Message envoyé (tronqué) |
| `status` | VARCHAR(20) | DEFAULT 'queued' | queued, sent, delivered, failed |
| `provider` | VARCHAR(30) | | africastalking, whatsapp_business, firebase, smtp |
| `provider_message_id` | VARCHAR(100) | | Pour suivi delivery |
| `failure_reason` | VARCHAR(300) | | |
| `sent_at` | TIMESTAMPTZ | | |
| `delivered_at` | TIMESTAMPTZ | | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

---

### 2.3 Comptage final

| Module | Tables | Dont portées du Sprint 2 |
|---|:---:|:---:|
| IAM | 5 | 0 |
| Flotte | 6 | 0 |
| Géographie | 2 | 0 |
| Voyage (passagers) | 14 | 10 |
| Colis (logistique) | 4 | 0 |
| Facturation | 5 | 0 |
| Tracking | 4 | 0 |
| Notifications | 2 | 0 |
| **Total** | **42** | **10** |

Les 10 tables portées directement du Sprint 2 conservent leurs colonnes, types, et sémantique. Les noms sont normalisés en snake_case Django (`ToupacVoyage\Models\Passenger` → `voyage.Passenger` → table `voyage_passengers` avec le préfixe app Django).

---

### 2.4 ERD Mermaid (relations inter-modules)

Voir le diagramme ERD rendu ci-dessous.
-e 

---

# TOUPAC — Architecture Document v1.0

## Section 3 — Architecture applicative

### 3.0 Addendum Section 2 : Module Workflow (4 tables)

Le cahier des charges §4.4 décrit des "États Commande" (brouillon → planifiée → assignée → en cours → livrée → échec → annulée) et le Sprint 2 Fleetbase utilisait un `OrderConfig.flow` (JSONB blob de 9 activités avec 14 champs chacune). Les deux approches ont des défauts :

- **Le CdC** liste des statuts sans définir les transitions autorisées ni les side-effects.
- **Fleetbase OrderConfig** stocke tout le workflow dans un seul champ JSONB. Ça marche, mais c'est impossible à requêter (« quels workflows ont un état boarding ? »), impossible à valider au niveau DB, et le format OBJET (§4.9 J5-STATE) avec ses 14 champs obligatoires par activité est fragile.

**Ma recommandation** : un module Workflow relationnel en 4 tables. Le workflow est défini en DB (pas hardcodé), configurable par tenant, avec une séparation nette entre l'**ordre d'affichage** (linéaire, pour le stepper UI) et le **graphe de transitions** (plus flexible, pour l'API).

#### Leçon §4.9 traduite en règles de conception

| Contrainte Fleetbase | Règle TOUPAC |
|---|---|
| "PAS de cycles bidirectionnels → stack overflow" | La table `workflow_transitions` interdit `(A→B) + (B→A)` via contrainte applicative. Le graphe est un DAG (Directed Acyclic Graph) avec une seule exception : la transition vers `cancelled` depuis tout état |
| "Flow linéaire pour l'affichage" | Chaque état a un `display_order` (1, 2, 3...) qui pilote le stepper/progress bar UI. Le graphe de transitions peut sauter des états (ex : `scheduled → cancelled`) sans casser l'affichage |
| "L'activité created DOIT être présente" | Chaque workflow a exactement un état `is_initial = true`. Contrainte UNIQUE partielle |
| "14 champs par activité (color, logic, events, actions, pod_method...)" | Les métadonnées configurables vivent dans un JSONB `config` sur `workflow_states`, pas dans 14 colonnes. Seuls `code`, `label`, `color`, `display_order` sont des colonnes pour la performance des requêtes |

---

#### Schéma du module Workflow

**`workflow_definitions`** — Un workflow par type d'entité et par tenant. Remplace `order_configs`.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `tenant_id` | UUID | FK tenants | NULL = workflow système (template par défaut) |
| `entity_type` | VARCHAR(30) | NOT NULL | trip, order, delivery_task, parcel, incident |
| `name` | VARCHAR(100) | NOT NULL | "Voyage passagers standard", "Livraison express" |
| `description` | TEXT | | |
| `version` | INTEGER | NOT NULL, DEFAULT 1 | Versionné — on crée une nouvelle version au lieu de modifier |
| `is_active` | BOOLEAN | DEFAULT true | Une seule version active par (tenant, entity_type) |
| `is_system` | BOOLEAN | DEFAULT false | true = template fourni par TOUPAC, non supprimable |
| `created_by` | UUID | FK users | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(tenant_id, entity_type) WHERE is_active = true` — garantit un seul workflow actif par type et par tenant.

**`workflow_states`** — États/activités au sein d'un workflow.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `workflow_id` | UUID | FK workflow_definitions, NOT NULL | |
| `code` | VARCHAR(30) | NOT NULL | Identifiant machine : `scheduled`, `preparing`, `boarding`, `in_transit`... |
| `label` | VARCHAR(50) | NOT NULL | Label humain : "Préparation embarquement" |
| `color` | VARCHAR(7) | DEFAULT '#6B7280' | Hex pour le stepper UI |
| `display_order` | SMALLINT | NOT NULL | Ordre linéaire dans le stepper (1, 2, 3...) |
| `is_initial` | BOOLEAN | DEFAULT false | Exactement 1 par workflow |
| `is_terminal` | BOOLEAN | DEFAULT false | Peut être multiple (completed, cancelled) |
| `config` | JSONB | DEFAULT '{}' | Métadonnées configurables (remplace les 14 champs Fleetbase) |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Le champ `config` JSONB supporte les clés suivantes (toutes optionnelles) :

```json
{
  "require_pod": false,
  "pod_method": "signature|photo|qr_scan|otp",
  "auto_transition_after_minutes": null,
  "required_fields": ["driver_id", "vehicle_id"],
  "allowed_roles": ["dispatcher", "controller", "admin"],
  "notifications": [
    {"channel": "sms", "template": "trip_departure_reminder", "to": "passengers"}
  ],
  "webhooks": ["order.status.changed"],
  "ui_instructions": "Le contrôleur scanne les billets"
}
```

Index unique : `(workflow_id, code)`, `(workflow_id, display_order)`.

Contrainte applicative : exactement 1 état avec `is_initial = true` par workflow.

**`workflow_transitions`** — Transitions autorisées entre états. C'est le graphe.

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `workflow_id` | UUID | FK workflow_definitions, NOT NULL | |
| `from_state_id` | UUID | FK workflow_states, NOT NULL | |
| `to_state_id` | UUID | FK workflow_states, NOT NULL | |
| `trigger` | VARCHAR(20) | NOT NULL, DEFAULT 'manual' | manual, automatic, on_event, on_condition |
| `event_type` | VARCHAR(50) | | Pour trigger=on_event : quel event déclenche (ex: `first_boarding`, `all_delivered`) |
| `guard` | JSONB | DEFAULT '{}' | Conditions pour autoriser la transition |
| `priority` | SMALLINT | DEFAULT 0 | Si plusieurs transitions possibles, laquelle évaluer en premier |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Index unique : `(workflow_id, from_state_id, to_state_id)`.

Le champ `guard` supporte :

```json
{
  "all_parcels_status": "delivered",
  "anomalies_critical_resolved": true,
  "min_boarded_percent": 0,
  "require_role": "dispatcher",
  "require_field_not_null": ["driver_id"]
}
```

**`workflow_hooks`** — Side-effects déclenchés lors d'une transition (notifications, champs à mettre à jour, webhooks).

| Colonne | Type | Contrainte | Notes |
|---|---|---|---|
| `id` | UUID v7 | PK | |
| `transition_id` | UUID | FK workflow_transitions, NOT NULL | |
| `hook_type` | VARCHAR(20) | NOT NULL | notify, update_field, webhook, celery_task |
| `config` | JSONB | NOT NULL | Configuration du hook |
| `execution_order` | SMALLINT | DEFAULT 0 | |
| `created_at` | TIMESTAMPTZ | NOT NULL | |

Exemples de `config` par `hook_type` :

```json
// hook_type = "notify"
{"channel": "push", "template": "trip_boarding_started", "recipients": "passengers_booked"}

// hook_type = "update_field"  
{"field": "actual_departure_at", "value": "NOW()"}

// hook_type = "webhook"
{"event": "trip.status.changed", "include_payload": true}

// hook_type = "celery_task"
{"task": "voyage.tasks.generate_manifest_pdf", "kwargs": {"trip_id": "$entity.id"}}
```

---

#### Workflows système pré-seedés

TOUPAC fournit des workflows par défaut (is_system=true, tenant_id=NULL) que chaque tenant hérite automatiquement. Un tenant peut les cloner et les personnaliser.

**Workflow "Voyage passagers" (entity_type=trip)** — Port direct du flow Sprint 2 :

```
[1] scheduled → [2] preparing → [3] boarding → [4] in_transit 
    → [5] at_stop → [6] arriving → [7] completed
                                               ↗
    (tout état) ─────────────────→ [8] cancelled
```

| display_order | code | label | is_initial | is_terminal | Transition déclencheur |
|:---:|---|---|:---:|:---:|---|
| 1 | `scheduled` | Programmé | ✅ | | Création du trip |
| 2 | `preparing` | Préparation | | | `control/open` (contrôleur ouvre session) |
| 3 | `boarding` | Embarquement | | | Premier `reservation.board` |
| 4 | `in_transit` | En route | | | Départ (contrôleur ou auto) |
| 5 | `at_stop` | À l'escale | | | Arrivée à un `trip_stop` |
| 6 | `arriving` | Arrivée | | | Dernière escale |
| 7 | `completed` | Terminé | | ✅ | `control/close` |
| 8 | `cancelled` | Annulé | | ✅ | Annulation manuelle |

Transitions : `1→2`, `2→3`, `3→4`, `4→5`, `5→4` (retour en route après escale — seule "boucle" autorisée car `4→5→4` n'est pas bidirectionnel au sens Ember, c'est un cycle entre 2 états non-adjacents dans le display), `5→6`, `6→7`, `1→8`, `2→8`, `3→8`.

**Workflow "Commande colis" (entity_type=order)** :

```
[1] draft → [2] confirmed → [3] dispatched → [4] picked_up 
    → [5] in_transit → [6] delivered
                                    ↗
    (1-5) ──────────→ [7] failed
    (1-3) ──────────→ [8] cancelled
```

| display_order | code | label | is_initial | is_terminal |
|:---:|---|---|:---:|:---:|
| 1 | `draft` | Brouillon | ✅ | |
| 2 | `confirmed` | Confirmée | | |
| 3 | `dispatched` | Dispatchée | | |
| 4 | `picked_up` | Enlevée | | |
| 5 | `in_transit` | En transit | | |
| 6 | `delivered` | Livrée | | ✅ |
| 7 | `failed` | Échouée | | ✅ |
| 8 | `cancelled` | Annulée | | ✅ |

**Workflow "Tâche livraison" (entity_type=delivery_task)** :

```
[1] pending → [2] assigned → [3] accepted → [4] en_route 
    → [5] arrived → [6] completed
                              ↗
    (2-5) ──────→ [7] failed
```

---

#### Comptage mis à jour

| Module | Tables Section 2 | + Workflow | Total |
|---|:---:|:---:|:---:|
| IAM | 5 | — | 5 |
| Flotte | 6 | — | 6 |
| Géographie | 2 | — | 2 |
| Voyage | 14 | — | 14 |
| Colis | 4 | — | 4 |
| Facturation | 5 | — | 5 |
| Tracking | 4 | — | 4 |
| Notifications | 2 | — | 2 |
| **Workflow** | — | **4** | **4** |
| **Total** | **42** | **4** | **46** |

---

### 3.1 Structure du projet Django

```
toupac/
├── config/                    # Projet Django (settings, urls, asgi, wsgi)
│   ├── settings/
│   │   ├── base.py            # Settings communs
│   │   ├── dev.py             # DEBUG=True, SQLite fallback, CORS *
│   │   ├── staging.py
│   │   └── prod.py            # Cloud souverain SN
│   ├── urls.py                # Root URL conf → délègue aux modules
│   ├── asgi.py                # Entrypoint Daphne (WebSocket)
│   ├── wsgi.py                # Entrypoint Gunicorn (HTTP)
│   └── celery.py              # Entrypoint Celery
│
├── core/                      # Module transversal — pas d'API propre
│   ├── models.py              # TenantModel (base), UUIDv7Field, StatusField
│   ├── middleware.py           # TenantMiddleware, RequestIdMiddleware
│   ├── permissions.py         # TenantScopedPermission, RolePermission
│   ├── pagination.py          # StandardPagination (CdC : cohérent avec OpenAPI)
│   ├── exceptions.py          # ToupacAPIException, handler DRF custom
│   ├── mixins.py              # TenantQuerySetMixin, AuditMixin
│   └── utils.py               # generate_internal_id(), qr_jwt_sign()
│
├── iam/                       # Module IAM
│   ├── models.py              # Tenant, User, ApiCredential, AuditLog, UserDevice
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py               # Django Admin + unfold
│   ├── signals.py             # post_save → audit_log
│   ├── backends.py            # JWTAuthentication (simplejwt custom)
│   └── tasks.py               # Celery : purge sessions expirées
│
├── fleet/                     # Module Flotte
│   ├── models.py              # VehicleType, Vehicle, Driver, Fleet, FleetVehicle, VehicleDocument
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   ├── signals.py             # Document expiré → notification
│   └── tasks.py               # Celery : alertes expiration documents
│
├── geo/                       # Module Géographie (GeoDjango)
│   ├── models.py              # Place, Zone (PostGIS)
│   ├── serializers.py         # GeoFeatureSerializer (GeoJSON)
│   ├── views.py
│   ├── urls.py
│   └── admin.py               # Admin avec carte Leaflet (django-leaflet)
│
├── workflow/                  # Module Workflow (machine à états configurable)
│   ├── models.py              # WorkflowDefinition, WorkflowState, WorkflowTransition, WorkflowHook
│   ├── engine.py              # WorkflowEngine — cœur de la machine à états
│   ├── serializers.py
│   ├── views.py               # CRUD workflows (admin tenant)
│   ├── urls.py
│   ├── admin.py               # Admin : éditeur de workflow
│   ├── signals.py             # Post-transition → exécuter les hooks
│   ├── validators.py          # Valide le graphe (pas de cycles, 1 initial, ≥1 terminal)
│   ├── seed.py                # Workflows système par défaut
│   └── tasks.py               # Celery : transitions automatiques (timer-based)
│
├── voyage/                    # Module Voyage passagers
│   ├── models.py              # Route, RouteStop, Schedule, Trip, TripStop, Passenger,
│   │                          # Reservation, SeatMap, LuggagePolicy, Controller,
│   │                          # ControlSession, ControlEvent, Anomaly, Incident,
│   │                          # CashEntry, PassengerAccessLog
│   ├── serializers.py
│   ├── views.py               # TripViewSet, ReservationViewSet, ControlViewSet...
│   ├── urls.py                # /api/v1/voyage/...
│   ├── admin.py
│   ├── signals.py             # Reservation.boarded → Trip.booked_seats++
│   ├── services.py            # ControlEventProcessor (port des 481 lignes du Sprint 2)
│   ├── qr.py                  # JWT RS256 sign/verify pour QR billets
│   └── tasks.py               # Celery : génération manifeste PDF, rappels départ
│
├── colis/                     # Module Colis / logistique
│   ├── models.py              # Order, Parcel, DeliveryTask, ProofOfDelivery
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   ├── services.py            # DispatchService (appel VROOM), RouteService (appel OSRM)
│   └── tasks.py               # Celery : optimisation tournées VROOM, notifications client
│
├── billing/                   # Module Facturation
│   ├── models.py              # PriceList, PriceRule, Invoice, InvoiceLine, Payment
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   ├── services.py            # PricingEngine, InvoiceGenerator
│   ├── providers/             # Intégrations paiement
│   │   ├── base.py            # PaymentProvider (abstract)
│   │   ├── wave.py
│   │   ├── orange_money.py
│   │   ├── mtn_momo.py
│   │   └── cinetpay.py        # Agrégateur multi-pays
│   └── tasks.py               # Celery : vérification statut paiement, relances
│
├── tracking/                  # Module Tracking GPS
│   ├── models.py              # Position, Geofence, GeofenceEvent, TrackingLink
│   ├── serializers.py
│   ├── views.py               # PositionViewSet (lecture), TrackingLinkView (public)
│   ├── urls.py
│   ├── admin.py
│   ├── consumers.py           # Django Channels WebSocket consumer (positions live)
│   ├── routing.py             # WebSocket routing
│   ├── services.py            # TraccarBridge (sync positions Traccar → PostgreSQL)
│   └── tasks.py               # Celery : géofence check, purge positions anciennes
│
├── notifications/             # Module Notifications
│   ├── models.py              # NotificationTemplate, NotificationLog
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   ├── providers/             # Intégrations notification
│   │   ├── base.py            # NotificationProvider (abstract)
│   │   ├── africastalking.py  # SMS panafricain
│   │   ├── whatsapp.py        # WhatsApp Business API
│   │   ├── firebase.py        # Push (FCM)
│   │   └── smtp.py            # Email
│   └── tasks.py               # Celery : envoi asynchrone, retry avec backoff
│
└── api/                       # Couche API transversale
    ├── v1/
    │   ├── urls.py             # Agrège tous les modules sous /api/v1/
    │   └── throttling.py       # Rate limiting par tenant et par endpoint
    ├── versioning.py           # URLPathVersioning
    └── docs.py                 # drf-spectacular config (Swagger/OpenAPI auto-généré)
```

#### Convention de nommage Django → PostgreSQL

Django préfixe automatiquement les tables par le nom de l'app : `voyage_trips`, `colis_orders`, `billing_invoices`, etc. Cela évite les collisions et rend les requêtes SQL lisibles sans ambiguïté.

---

### 3.2 Le WorkflowEngine — cœur de la machine à états

Le fichier `workflow/engine.py` est le composant critique. Il remplace à la fois le `OrderConfig.flow` de Fleetbase et le composant Ember `addChildActivities()` qui crashait sur les cycles.

#### Interface publique

```python
class WorkflowEngine:
    """Machine à états configurable, chargée depuis la DB."""

    def get_workflow(self, tenant_id: UUID, entity_type: str) -> WorkflowDefinition:
        """Retourne le workflow actif pour ce tenant et ce type d'entité.
        Fallback sur le workflow système (tenant_id=NULL) si le tenant
        n'a pas de workflow custom."""

    def get_current_state(self, entity) -> WorkflowState:
        """Lit le champ `status` de l'entité et le résout en WorkflowState."""

    def get_available_transitions(self, entity, user) -> list[WorkflowTransition]:
        """Retourne les transitions possibles depuis l'état courant,
        filtrées par les guards (conditions) et le rôle de l'utilisateur."""

    def transition(self, entity, to_state_code: str, user, **context) -> entity:
        """Exécute une transition :
        1. Vérifie que la transition (current → to_state) existe
        2. Évalue les guards
        3. Met à jour entity.status
        4. Exécute les hooks (notifications, update_field, webhook, celery_task)
        5. Crée une entrée dans audit_logs
        Lève WorkflowTransitionError si refusé."""

    def validate_graph(self, workflow_id: UUID) -> list[str]:
        """Vérifie l'intégrité du workflow :
        - Exactement 1 état initial
        - Au moins 1 état terminal
        - Tous les états non-terminaux ont au moins 1 transition sortante
        - Pas de cycles bidirectionnels (A→B et B→A)
        - L'état initial est accessible en display_order=1
        Retourne une liste d'erreurs (vide = valide)."""
```

#### Séquence d'une transition

```
Client (app mobile ou admin)
    │
    ▼
API View (ex: POST /trips/{id}/control/open)
    │
    ├── 1. Charger l'entité (Trip)
    ├── 2. engine.get_current_state(trip) → "scheduled"
    ├── 3. engine.transition(trip, "preparing", user=controller)
    │       │
    │       ├── 3a. Chercher transition (scheduled → preparing) dans workflow
    │       ├── 3b. Évaluer guard: {} → OK
    │       ├── 3c. trip.status = "preparing" ; trip.save()
    │       ├── 3d. Exécuter hooks:
    │       │       ├── update_field: actual_departure_at = NOW()
    │       │       ├── notify: push "Embarquement ouvert" → passengers
    │       │       └── webhook: trip.status.changed → tenant.webhook_url
    │       └── 3e. AuditLog.create(action="transition", changes={"status": ["scheduled","preparing"]})
    │
    └── 4. Retourner la réponse API (trip mis à jour)
```

#### Pourquoi pas django-fsm ?

`django-fsm` est un bon package (états déclarés en décorateurs Python), mais les transitions sont hardcodées dans le modèle. TOUPAC a besoin de workflows **configurables par tenant** : une compagnie de transport interurbain n'a pas les mêmes états qu'un service de livraison express. Stocker les workflows en DB et les évaluer au runtime est la seule approche qui supporte le multi-tenant configurable.

---

### 3.3 State machines par entité

Chaque entité à workflow porte un champ `status VARCHAR(20)` qui est validé par le WorkflowEngine. Le status ne peut changer que via `engine.transition()` — jamais par affectation directe.

#### Trip (voyage passagers)

```
scheduled ──→ preparing ──→ boarding ──→ in_transit ──→ at_stop
                                                         │   ↑
                                                         │   │
    ┌──── cancelled ←── (depuis scheduled,               │   │
    │                    preparing, boarding)        arriving  │
    │                                                  │      │
    │                                                  ▼      │
    │                                            completed    │
    │                                                         │
    └── Le cycle at_stop ↔ in_transit est autorisé ──────────┘
        (escales multiples sur un trajet)
```

Transitions détaillées :

| De | Vers | Trigger | Guard | Hook principal |
|---|---|---|---|---|
| scheduled | preparing | `control/open` | controller assigné | Créer ControlSession |
| preparing | boarding | Premier `reservation.board` | — | — |
| boarding | in_transit | Manuel (contrôleur) | — | `actual_departure_at = NOW()` |
| in_transit | at_stop | Arrivée à un trip_stop | — | `trip_stop.ata = NOW()` |
| at_stop | in_transit | Départ d'une escale | — | `trip_stop.atd = NOW()` |
| at_stop | arriving | Dernière escale | `stop_order == max` | — |
| arriving | completed | `control/close` | Queue events vide, anomalies critiques résolues | Générer résumé, PDF manifeste |
| scheduled | cancelled | Manuel (dispatcher) | — | Notifier passagers |
| preparing | cancelled | Manuel | — | Notifier passagers |
| boarding | cancelled | Manuel (admin seulement) | — | Rembourser billets |

#### Order (commande colis)

```
draft ──→ confirmed ──→ dispatched ──→ picked_up ──→ in_transit ──→ delivered
  │           │              │             │              │
  └───────────┴──────────────┘             └──────────────┘
        → cancelled                           → failed
```

| De | Vers | Trigger | Guard | Hook principal |
|---|---|---|---|---|
| draft | confirmed | Validation client | Champs obligatoires remplis | Notifier dispatcher |
| confirmed | dispatched | VROOM assigne un chauffeur | driver_id, vehicle_id non null | Notifier chauffeur |
| dispatched | picked_up | Chauffeur confirme enlèvement | — | Notifier expéditeur |
| picked_up | in_transit | Automatique | — | Créer tracking_link, notifier destinataire |
| in_transit | delivered | POD capturée | proof_of_delivery exists | Notifier destinataire, générer facture |
| in_transit | failed | Chauffeur déclare échec | — | Notifier dispatcher + expéditeur |
| draft | cancelled | Manuel | — | — |
| confirmed | cancelled | Manuel | — | Notifier expéditeur |
| dispatched | cancelled | Manuel (dispatcher) | — | Notifier chauffeur + expéditeur |

#### DeliveryTask (tâche de livraison)

```
pending ──→ assigned ──→ accepted ──→ en_route ──→ arrived ──→ completed
                │            │           │           │
                └────────────┴───────────┴───────────┘
                                → failed
```

---

### 3.4 Architecture API (DRF)

#### URL namespace

```
/api/v1/
├── auth/                      # iam module
│   ├── login/                 # POST — JWT access + refresh
│   ├── refresh/               # POST — rotation tokens
│   └── logout/                # POST — révocation (denylist jti, §4.19)
│
├── tenants/                   # iam module (super-admin only)
│   └── {id}/
│
├── users/                     # iam module
│   └── me/                    # GET — profil courant
│
├── fleet/
│   ├── vehicle-types/
│   ├── vehicles/
│   │   └── {id}/documents/
│   ├── drivers/
│   └── fleets/
│
├── geo/
│   ├── places/
│   └── zones/
│
├── voyage/                    # Port des 19 endpoints Sprint 2
│   ├── routes/
│   │   └── {id}/stops/
│   ├── schedules/
│   ├── trips/
│   │   ├── {id}/
│   │   ├── {id}/manifest/     # GET — endpoint critique offline
│   │   ├── {id}/stops/
│   │   ├── {id}/control/open/ # POST
│   │   └── {id}/control/close/# POST
│   ├── reservations/
│   │   ├── {id}/board/        # POST
│   │   ├── {id}/refuse/       # POST
│   │   └── {id}/special-case/ # POST
│   ├── passengers/
│   │   └── {id}/              # GET (include_id_card → audit RGPD)
│   ├── controllers/
│   ├── control-events/batch/  # POST — endpoint critique offline sync
│   ├── anomalies/
│   ├── incidents/
│   └── uploads/presign/       # POST — URL pré-signée S3
│
├── colis/
│   ├── orders/
│   │   └── {id}/parcels/
│   ├── parcels/
│   │   └── {id}/
│   ├── delivery-tasks/
│   │   └── {id}/pod/          # POST — preuve de livraison
│   └── dispatch/optimize/     # POST — appel VROOM
│
├── billing/
│   ├── price-lists/
│   │   └── {id}/rules/
│   ├── invoices/
│   │   └── {id}/
│   ├── payments/
│   │   ├── initiate/          # POST — lance le paiement mobile money
│   │   └── webhook/           # POST — callback provider (CinetPay, PayDunya)
│   └── pricing/calculate/     # POST — simulation tarif
│
├── tracking/
│   ├── positions/             # GET — historique positions d'un véhicule
│   ├── live/                  # WebSocket (Django Channels)
│   ├── geofences/
│   └── links/                 # GET — suivi public par token
│
├── notifications/
│   ├── templates/
│   └── logs/
│
├── workflows/                 # workflow module
│   ├── definitions/
│   │   └── {id}/
│   │       ├── states/
│   │       └── transitions/
│   └── {entity_type}/{entity_id}/
│       ├── current-state/     # GET
│       └── available-transitions/ # GET
│
└── webhooks/                  # Réception webhooks externes (Traccar, paiement)
```

#### Chaîne de middlewares

```
Request HTTP
    │
    ▼
[1] SecurityMiddleware (Django — HTTPS, HSTS)
    │
[2] CorsMiddleware (django-cors-headers — origines autorisées)
    │
[3] RequestIdMiddleware (core — ajoute X-Request-Id pour le tracing)
    │
[4] TenantMiddleware (core — résout tenant_id depuis le JWT ou la session)
    │     ├── API mobile : tenant_id extrait du JWT claim `tenant_id`
    │     ├── Admin web : tenant_id extrait de la session Django
    │     └── API publique : tenant_id extrait de l'API key
    │
[5] AuthenticationMiddleware (Django + simplejwt)
    │     ├── JWT pour /api/v1/* (sauf auth/login et tracking/links)
    │     └── Session pour /admin/*
    │
[6] JWTDenylistMiddleware (core — vérifie que le jti n'est pas révoqué)
    │     Pattern §4.19 du Sprint 2 : cache Redis, TTL = durée restante
    │
[7] IdempotencyMiddleware (core — sur tous les POST/PUT/PATCH/DELETE)
    │     Header `Idempotency-Key: <uuid v4>` obligatoire
    │     Stocke la réponse en cache Redis (TTL 24h)
    │     Retourne la réponse cachée avec X-Idempotency-Replayed: true
    │
[8] AuditMiddleware (core — log les mutations dans audit_logs)
    │
    ▼
DRF View (ViewSet / APIView)
    │
    ▼
Response
```

#### Throttling par tenant

```python
# api/v1/throttling.py
THROTTLE_RATES = {
    'tenant_burst': '100/minute',    # Par tenant, toutes API
    'tenant_sustained': '5000/hour', # Par tenant, toutes API
    'auth_login': '10/minute',       # Anti brute-force login
    'batch_sync': '20/minute',       # control-events/batch
    'payment_initiate': '30/minute', # Paiement mobile money
}
```

---

### 3.5 Interaction entre modules

Le module Workflow est le liant entre les modules métier. Voici les principaux flux inter-modules :

**Flux 1 — Réservation d'un billet (Voyage + Billing + Notifications)**

```
App client → POST /voyage/reservations/
    │
    ├── voyage: crée Reservation (status=booked)
    ├── billing: PricingEngine.calculate(route, stops, luggage)
    ├── billing: Payment.initiate(provider=wave, amount=15000)
    │     └── [Celery] → CinetPay/PayDunya API
    ├── voyage: qr.sign_ticket_jwt(reservation) → qr_code_jwt
    └── [Celery] notifications: SMS confirmation + billet QR WhatsApp
```

**Flux 2 — Sync offline contrôleur (Voyage + Workflow)**

```
App contrôleur → POST /voyage/control-events/batch
    │
    ├── Pour chaque event (port du ControlEventProcessor Sprint 2):
    │   ├── Idempotence: client_uuid déjà vu? → skip
    │   ├── Dispatch par event_type:
    │   │   ├── reservation_board → workflow.transition(reservation, "boarded")
    │   │   ├── reservation_refuse → workflow.transition(reservation, "refused") + anomalie
    │   │   ├── onboard_sale → create Passenger + Reservation + CashEntry
    │   │   ├── parcel_verify → voyage: marquer colis vérifié
    │   │   ├── anomaly_create → voyage: créer Anomaly
    │   │   └── ...
    │   └── Auto-anomalies: duplicate_scan, seat_conflict, parcel_non_conform
    │
    └── Réponse: verdict par event (accepted/rejected + anomaly éventuelle)
```

**Flux 3 — Dispatch optimisé (Colis + Fleet + Tracking)**

```
Dispatcher → POST /colis/dispatch/optimize
    │
    ├── colis: récupérer commandes confirmées non-dispatchées
    ├── fleet: récupérer véhicules et chauffeurs disponibles
    ├── geo: positions actuelles des véhicules (Traccar)
    ├── [Celery] → VROOM API (optimisation VRP)
    │     └── VROOM consulte OSRM pour les distances/temps
    ├── colis: créer DeliveryTasks avec sequence_order
    ├── workflow: transition orders confirmed → dispatched
    └── [Celery] notifications: push aux chauffeurs assignés
```

**Flux 4 — Paiement mobile money callback (Billing + Voyage/Colis + Notifications)**

```
CinetPay/PayDunya → POST /billing/payments/webhook
    │
    ├── billing: vérifier signature webhook
    ├── billing: Payment.status = success/failed
    ├── Si voyage: Reservation.payment_status = paid
    │   └── workflow.transition(reservation, "checked_in")
    ├── Si colis: Order.payment_status = paid
    │   └── workflow.transition(order, "confirmed")
    └── [Celery] notifications: SMS/WhatsApp confirmation paiement
```
-e 

---

# TOUPAC — Architecture Document v1.0

## Section 4 — Infrastructure & déploiement

### 4.1 Topologie Docker Compose (production)

9 services depuis 5 images distinctes. Les 3 services Django partagent la même image (entrypoint différent).

```yaml
# docker-compose.prod.yml — structure simplifiée
services:

  # ─── Reverse proxy ───
  caddy:
    image: caddy:2-alpine
    ports: ["443:443", "80:80"]
    # TLS automatique via Let's Encrypt (ou cert manuel cloud souverain)
    # Proxy: /api/* → toupac-web:8000
    # Proxy: /ws/*  → toupac-ws:8001
    # Proxy: /admin/* → toupac-web:8000
    # Static files: /static/* → volume partagé
    volumes: [caddy_data:/data, static_files:/srv/static:ro]
    restart: always
    mem_limit: 128m

  # ─── Django : API + Admin ───
  toupac-web:
    image: toupac/app:${TAG}
    command: >
      gunicorn config.wsgi:application
      --bind 0.0.0.0:8000
      --workers 4
      --worker-class uvicorn.workers.UvicornWorker
      --timeout 30
      --access-logfile -
    env_file: .env.prod
    volumes: [static_files:/app/staticfiles, media_files:/app/media]
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 1g
    # healthcheck: curl -f http://localhost:8000/health/

  # ─── Django : Celery worker ───
  toupac-worker:
    image: toupac/app:${TAG}
    command: >
      celery -A config worker
      --loglevel=info
      --concurrency=4
      --max-tasks-per-child=1000
    env_file: .env.prod
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 1g

  # ─── Django : Celery Beat (scheduler) ───
  toupac-beat:
    image: toupac/app:${TAG}
    command: celery -A config beat --loglevel=info --scheduler django_celery_beat.schedulers:DatabaseScheduler
    env_file: .env.prod
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 256m

  # ─── Django : WebSocket (Channels) ───
  toupac-ws:
    image: toupac/app:${TAG}
    command: daphne -b 0.0.0.0 -p 8001 config.asgi:application
    env_file: .env.prod
    depends_on: [redis]
    restart: always
    mem_limit: 512m

  # ─── PostgreSQL + PostGIS ───
  postgres:
    image: postgis/postgis:16-3.4-alpine
    volumes: [pg_data:/var/lib/postgresql/data]
    environment:
      POSTGRES_DB: toupac
      POSTGRES_USER: toupac
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    restart: always
    mem_limit: 2g
    # pg_hba.conf : connexions locales uniquement (pas d'accès externe)

  # ─── Redis ───
  redis:
    image: redis:7-alpine
    command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru --appendonly yes
    volumes: [redis_data:/data]
    restart: always
    mem_limit: 384m

  # ─── Traccar (tracking GPS) ───
  traccar:
    image: traccar/traccar:6-alpine
    ports: ["5055:5055/tcp", "5055:5055/udp"]
    # Port 5055 = protocole OsmAnd (apps mobiles)
    # Ports additionnels selon les trackers GPS physiques utilisés
    volumes: [traccar_data:/opt/traccar/data]
    environment:
      # Traccar peut utiliser PostgreSQL partagé ou sa DB H2 interne
      CONFIG_FILE: /opt/traccar/conf/traccar.xml
    restart: always
    mem_limit: 512m

  # ─── OSRM (routing Afrique de l'Ouest) ───
  osrm:
    image: ghcr.io/project-osrm/osrm-backend:v5.27.1
    command: osrm-routed --algorithm mld /data/africa-west-latest.osrm
    volumes: [osrm_data:/data:ro]
    restart: always
    mem_limit: 6g
    # Données pré-processées hors container (voir §4.3)

  # ─── VROOM (optimisation tournées) ───
  vroom:
    image: vroomvrp/vroom-docker:v1.14.0
    environment:
      VROOM_ROUTER: osrm
      OSRM_URL: http://osrm:5000
    restart: always
    mem_limit: 512m

volumes:
  pg_data:
  redis_data:
  caddy_data:
  static_files:
  media_files:
  traccar_data:
  osrm_data:
```

#### Bilan des ressources (estimation prod initiale)

| Service | RAM | CPU | Stockage |
|---|---|---|---|
| Caddy | 128 Mo | 0.1 vCPU | Négligeable |
| toupac-web (4 workers) | 1 Go | 1 vCPU | — |
| toupac-worker (4 workers) | 1 Go | 1 vCPU | — |
| toupac-beat | 256 Mo | 0.1 vCPU | — |
| toupac-ws (Daphne) | 512 Mo | 0.5 vCPU | — |
| PostgreSQL + PostGIS | 2 Go | 1 vCPU | 50 Go SSD (croissance ~1 Go/mois) |
| Redis | 384 Mo | 0.2 vCPU | 1 Go |
| Traccar | 512 Mo | 0.5 vCPU | 10 Go |
| OSRM (Afrique Ouest) | **6 Go** | 1 vCPU | 15 Go (données OSM pré-processées) |
| VROOM | 512 Mo | 0.5 vCPU | — |
| **Total** | **~12 Go** | **~6 vCPU** | **~80 Go SSD** |

**Recommandation serveur** : VPS 8 vCPU / 16 Go RAM / 200 Go SSD NVMe pour démarrer. Marge de 4 Go pour les pics. Passer à 32 Go RAM quand le nombre de véhicules trackés dépasse 200 en simultané (Traccar + OSRM sous charge).

---

### 4.2 Cloud souverain sénégalais

**Ce que dit la contrainte** : les données doivent être hébergées au Sénégal. Les données de clients ivoiriens, maliens, etc. sont hébergées au SN — les CGU TOUPAC doivent le mentionner explicitement.

**Options de providers** (à valider avec la direction — les prix évoluent) :

| Provider | Offre | Avantage | Point d'attention |
|---|---|---|---|
| **Africa Cloud / Sonatel** | VPS, bare metal, object storage | Infrastructure Sonatel/Orange, peering local excellent | Vérifier SLA 99.9%, support Docker |
| **CGSI (Centre de Gestion des Systèmes Informatiques)** | Hébergement datacenter Dakar | Souveraineté gouvernementale | Destiné aux institutions, vérifier éligibilité privée |
| **Etix Everywhere Dakar** | Colocation datacenter Tier III | Fiabilité, certifications | Colocation = on gère le serveur soi-même |
| **VPS international avec contrainte Dakar** | OVH, Hetzner, DigitalOcean | Pas de datacenter à Dakar | ❌ Ne satisfait pas la contrainte |

**Ce que je recommande** : contacter Africa Cloud / Sonatel et Etix Everywhere pour un devis VPS 8 vCPU / 16 Go / 200 Go. Budget estimé : 150 000 à 300 000 XOF/mois (~230-460 €). L'alternative est un serveur dédié en colocation chez Etix (~500-800 €/mois avec le matériel amorti sur 3 ans).

**Backup du backup** : si aucun provider souverain n'offre un SLA 99.9% acceptable, un setup multi-site est envisageable : primaire au SN (données), CDN + failover hors SN (statique uniquement, pas de données personnelles). Mais ça complexifie l'opérationnel — à éviter en V1.

---

### 4.3 OSRM — données Afrique de l'Ouest

OSRM a besoin de données OpenStreetMap pré-processées. Pour couvrir les 15 pays UEMOA + CEDEAO :

```bash
# Télécharger l'extrait Geofabrik Afrique de l'Ouest (~1.2 Go)
wget https://download.geofabrik.de/africa/western-africa-latest.osm.pbf

# Pré-traitement (à faire sur une machine avec ≥8 Go RAM, pas sur le serveur prod)
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-extract -p /opt/car.lua /data/western-africa-latest.osm.pbf
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-partition /data/western-africa-latest.osrm
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-customize /data/western-africa-latest.osrm

# Résultat : ~5-8 Go de fichiers .osrm.* à monter dans le container prod
```

**Mise à jour mensuelle** : Geofabrik met à jour ses extraits quotidiennement. Un cron mensuel télécharge, pré-traite sur un serveur de build, et remplace les fichiers sur le serveur prod (volume Docker). Downtime OSRM : ~2 minutes (restart du container).

**Profil de routing** : `car.lua` par défaut. Si TOUPAC gère des motos ou des vélos (livraison urbaine), il faudra des profils additionnels. Chaque profil = un jeu de données pré-traité séparé (~5 Go de plus par profil).

---

### 4.4 Object Storage (S3-compatible)

Photos (POD, incidents, CNI passagers), documents (factures PDF, manifestes), fichiers uploadés. Ne pas stocker ça dans PostgreSQL.

| Option | Notes |
|---|---|
| **MinIO** (self-hosted) | S3-compatible, 1 container de plus, gratuit. Recommandé V1 si pas d'offre S3 chez le provider souverain |
| **Object storage du provider** | Si Africa Cloud / Sonatel propose un stockage objet S3-compatible, l'utiliser plutôt que self-hosted |

Django utilise `django-storages` avec le backend S3 — transparent, les fichiers sont accédés par URL signée (pas de lecture directe depuis la DB).

Estimation stockage : ~5 Go/mois/tenant actif (photos POD, documents). Prévoir 100 Go pour la première année tous tenants confondus.

---

### 4.5 CI/CD — GitHub Actions

```yaml
# .github/workflows/ci.yml
name: CI/CD TOUPAC

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgis/postgis:16-3.4-alpine
        env:
          POSTGRES_DB: toupac_test
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
        ports: ["5432:5432"]
      redis:
        image: redis:7-alpine
        ports: ["6379:6379"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pip install -r requirements/dev.txt
      - run: python manage.py migrate --settings=config.settings.test
      - run: pytest --cov=. --cov-report=xml -x
      - run: ruff check .
      - run: ruff format --check .

  build:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/build-push-action@v5
        with:
          push: true
          tags: toupac/app:${{ github.sha }},toupac/app:latest
          # Registry privé (GitHub Container Registry ou registry self-hosted)

  deploy-staging:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - name: Deploy via SSH
        run: |
          ssh deploy@staging.toupac.sn "
            cd /opt/toupac &&
            docker compose pull &&
            docker compose up -d --remove-orphans &&
            docker compose exec -T toupac-web python manage.py migrate --no-input &&
            docker compose exec -T toupac-web python manage.py collectstatic --no-input
          "

  deploy-prod:
    needs: build
    if: github.ref == 'refs/heads/main'
    environment: production   # Require manual approval
    runs-on: ubuntu-latest
    steps:
      - name: Deploy via SSH
        run: |
          ssh deploy@api.toupac.sn "
            cd /opt/toupac &&
            TAG=${{ github.sha }} docker compose -f docker-compose.prod.yml pull &&
            TAG=${{ github.sha }} docker compose -f docker-compose.prod.yml up -d --remove-orphans &&
            docker compose exec -T toupac-web python manage.py migrate --no-input
          "
```

**Branching** : `develop` pour l'intégration continue (déploie sur staging auto), `main` pour la prod (déploie après approbation manuelle via GitHub Environments).

---

### 4.6 Backups

| Quoi | Fréquence | Rétention | Comment |
|---|---|---|---|
| PostgreSQL (dump complet) | Quotidien, 3h du matin UTC | 30 jours | `pg_dump --format=custom` → objet storage ou stockage externe |
| PostgreSQL (WAL archiving) | Continu | 7 jours | Point-in-time recovery en cas de corruption |
| Redis (RDB snapshot) | Toutes les heures | 48h | Persistence AOF activée, snapshot RDB en complément |
| Object storage (media) | Quotidien (incremental) | 90 jours | `rclone sync` vers un second emplacement |
| Volumes Docker (Traccar, OSRM) | Hebdomadaire | 4 semaines | Reconstituable depuis les sources, backup de confort |

**Test de restauration** : une fois par mois, restaurer le backup PostgreSQL sur l'environnement staging et vérifier l'intégrité. Automatiser ce test dans le CI (job mensuel).

**Chiffrement** : les backups PostgreSQL sont chiffrés au repos (GPG ou age) avant transfert. La clé de chiffrement est stockée hors du serveur de backup (gestionnaire de secrets ou coffre-fort physique).

---

### 4.7 Monitoring & observabilité

Stack légère, pas de cluster Prometheus/Grafana en V1 (budget startup).

| Couche | Outil | Coût |
|---|---|---|
| **Uptime** | UptimeRobot ou Hetrix (plan gratuit) | 0 € — check HTTP toutes les 5 min, alertes SMS/email |
| **Logs** | Docker JSON logs + `docker compose logs --tail=1000` | 0 € — suffisant V1 |
| **Logs (upgrade V1.5)** | Loki + Grafana (self-hosted, 1 container) | 0 € — quand les logs Docker bruts ne suffisent plus |
| **Métriques applicatives** | `django-prometheus` → Prometheus (self-hosted) | 0 € — expose /metrics, un container Prometheus scrape |
| **Métriques système** | `node_exporter` + Prometheus | 0 € — CPU, RAM, disk, réseau |
| **APM (traces)** | Sentry self-hosted ou sentry.io (plan dev gratuit) | 0 € — traces d'erreurs Python avec stack trace et contexte |
| **Alertes** | Prometheus Alertmanager ou UptimeRobot | SMS/email quand : CPU > 80% 5min, RAM > 90%, disk > 85%, 5xx > 10/min, Celery queue > 100 |

**V1 minimal** : UptimeRobot (gratuit, 5 monitors) + Sentry (plan dev, 5000 events/mois) + `docker compose logs`. Ça couvre les pannes et les erreurs applicatives. Le reste vient quand l'équipe grandit.

---

### 4.8 Sécurité

| Mesure | Implémentation |
|---|---|
| **TLS partout** | Caddy gère les certificats Let's Encrypt automatiquement. Si le provider souverain n'expose pas les ports 80/443, cert manuel + Caddy en mode TLS passthrough |
| **Firewall** | UFW : seuls les ports 80, 443, 22 (SSH) et 5055 (Traccar GPS) sont ouverts. PostgreSQL, Redis, OSRM, VROOM ne sont PAS exposés — communication inter-container uniquement |
| **SSH** | Clé ED25519 uniquement, password auth désactivé, fail2ban |
| **Secrets** | `.env.prod` avec `chmod 600`, jamais commité. V2 : Vault ou SOPS |
| **DB** | `pg_hba.conf` : connexions locales (socket unix) et réseau Docker uniquement. Pas d'accès TCP externe |
| **Django** | `SECURE_HSTS_SECONDS`, `CSRF_COOKIE_SECURE`, `SESSION_COOKIE_SECURE`, `SECURE_SSL_REDIRECT` — tous à true en prod |
| **Rate limiting** | DRF throttling par tenant (§3.4). Caddy rate-limit global en complément |
| **Headers** | `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Content-Security-Policy` — via Caddy |
| **Dépendances** | `pip-audit` + `safety` dans le CI. Dependabot activé sur GitHub |
| **RGPD-like géoloc chauffeurs** | Les positions GPS sont purgées après 90 jours (Celery Beat task). Accès aux CNI passagers audité dans `passenger_access_log` (§Sprint 2 pattern) |

---

## Section 5 — Roadmap de migration

### 5.0 Point de départ

On part d'ici (24 août 2026) :

| Actif | Statut | Portabilité |
|---|---|---|
| 19 endpoints API documentés (OpenAPI v1.1.0) | ✅ Validé | Spécification pour la réécriture Django |
| Collection Postman 20 requêtes | ✅ Validé | Tests de non-régression |
| Schéma DB 12 tables custom | ✅ Validé | Migration DDL directe (10 tables portées, 2 supprimées) |
| Protocole offline-sync (ControlEventProcessor, 481 lignes) | ✅ Validé | Port en Python, logique métier identique |
| QR billet JWT RS256 | ✅ Validé | `PyJWT` + clé RSA |
| Test multi-tenant 8/8 | ✅ Validé | Pattern `tenant_id` directement applicable |
| App contrôleur React Native (équipier séparé) | 🔄 En cours | Continue en parallèle, consomme l'API v1 identique |
| Figma (3 apps mobiles) | ✅ Disponible | Référence UX inchangée |
| Cahier des charges | ✅ Disponible | Inchangé |

**Deadline MVP initiale** : 19 septembre 2026 (J5-STATE §8). Cette date est **caduque** pour le backend — le pivot de stack impose un nouveau calendrier. L'app contrôleur React Native continue sur son planning propre (elle consomme l'API, elle n'est pas couplée au framework backend).

---

### 5.1 Planning par sprint (2 semaines chacun)

#### Sprint 0 — Fondations (semaines 1-2)

**Objectif** : projet Django bootable, CI verte, premiers modèles en DB, admin fonctionnel.

| Tâche | Jours | Livrable |
|---|---|---|
| Init projet Django 5 + DRF + config settings (dev/staging/prod) | 1 | Repo GitHub, structure §3.1 |
| Docker Compose dev (Django + PostgreSQL/PostGIS + Redis) | 1 | `docker compose up` fonctionnel |
| Module `core` : TenantModel, UUIDv7Field, TenantMiddleware, TenantQuerySetMixin | 1 | Base technique multi-tenant |
| Module `iam` : modèles Tenant, User + Django Admin + unfold | 1 | Admin accessible, création tenant/user |
| Module `iam` : auth JWT (simplejwt) + denylist jti (port du pattern §4.19) | 1 | `POST /auth/login`, `POST /auth/refresh`, `POST /auth/logout` |
| CI GitHub Actions : pytest + ruff + build Docker | 0.5 | Pipeline verte |
| Module `workflow` : modèles WorkflowDefinition, WorkflowState, WorkflowTransition, WorkflowHook | 1 | Tables créées, admin CRUD |
| Seed workflows système (Trip, Order, DeliveryTask) | 0.5 | Workflows par défaut en DB |
| Module `fleet` : Vehicle, Driver, VehicleType (modèles + admin) | 1 | CRUD véhicules/chauffeurs dans l'admin |
| Module `geo` : Place, Zone (PostGIS + admin django-leaflet) | 1 | Places avec carte dans l'admin |
| **Démo interne** | — | Admin multi-tenant : créer un tenant, des users, des véhicules, des chauffeurs, des places sur une carte |

**Livrable Sprint 0** : Django Admin fonctionnel avec multi-tenant, auth JWT, CRUD flotte et géographie.

---

#### Sprint 1 — Module Voyage core (semaines 3-4)

**Objectif** : port des 10 tables voyage + les 4 nouvelles (routes, route_stops, schedules, trip_stops). API voyage reconstituée.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles Route, RouteStop, Schedule, SeatMap, LuggagePolicy + admin | 2 | Gestion des lignes et horaires dans l'admin |
| Modèles Trip, TripStop + WorkflowEngine intégration + admin | 2 | Création de voyages, transitions de statut via admin |
| Modèles Passenger, Reservation + QR JWT RS256 (`PyJWT`) | 1.5 | Port direct des tables Sprint 2 |
| Modèles Controller, ControlSession | 0.5 | Port direct |
| API DRF : endpoints Trips (list, detail, manifest) | 1.5 | `GET /voyage/trips/`, `GET /voyage/trips/{id}/manifest` |
| API DRF : endpoints Auth contrôleur (login, refresh, logout) | 1 | Port des 3 endpoints Sprint 2 |
| API DRF : endpoints Reservations (board, refuse, special-case, onboard sale) | 1.5 | Port des 4 endpoints Sprint 2 |
| **Validation Postman** | — | Rejouer la collection Postman Sprint 2 sur la nouvelle API |

**Livrable Sprint 1** : API voyage fonctionnelle, validée par la collection Postman existante. L'app contrôleur React Native peut pointer dessus.

---

#### Sprint 2 — Offline sync + anomalies (semaines 5-6)

**Objectif** : port du ControlEventProcessor et du protocole offline complet.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles ControlEvent, Anomaly, Incident, CashEntry | 1 | Port direct des 4 tables restantes |
| IdempotencyMiddleware (header `Idempotency-Key`, cache Redis) | 1 | Idempotence sur tous les POST |
| Port du ControlEventProcessor (481 lignes PHP → Python) | 3 | Dispatch des 10 event_type + auto-anomalies |
| API DRF : `POST /control-events/batch` | 1 | Endpoint critique offline sync |
| API DRF : anomalies, incidents, passengers, uploads/presign | 1.5 | Les 6 endpoints restants du Sprint 2 |
| WorkflowEngine : transitions Trip via ControlEventProcessor | 1 | `preparing → boarding` au premier board, etc. |
| Test multi-tenant (port du test 8/8 du Sprint 2 §6.2) | 0.5 | Aucune fuite cross-tenant |
| **Validation complète** | — | 20/20 endpoints Postman verts, isolation tenant validée |

**Livrable Sprint 2** : parité fonctionnelle complète avec le Sprint 2 Fleetbase. Tous les patterns validés (offline sync, idempotence, auto-anomalies, multi-tenant isolation) fonctionnent sur Django. L'app contrôleur React Native peut basculer sur le nouveau backend sans modification.

**⚠️ Milestone critique** : à ce stade, l'équipier React Native peut reconnecter son app au nouveau backend. Le contrat API (OpenAPI v1.1.0) est identique — seuls les URLs de base changent.

---

#### Sprint 3 — Module Colis (semaines 7-8)

**Objectif** : commandes de livraison, colis, dispatch, POD.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles Order, Parcel, DeliveryTask, ProofOfDelivery + admin | 2 | CRUD colis dans l'admin |
| WorkflowEngine : flow Order + flow DeliveryTask | 1 | State machines configurables |
| API DRF : CRUD orders, parcels, delivery-tasks, POD | 3 | API complète module colis |
| Intégration VROOM : `POST /colis/dispatch/optimize` | 1.5 | Appel HTTP vers container VROOM |
| Intégration OSRM : calcul ETA, route polyline | 1 | Appel HTTP vers container OSRM |
| Tracking links publics : `GET /tracking/links/{token}` | 0.5 | Suivi public par URL |
| Setup containers VROOM + OSRM en Docker Compose dev | 1 | Données OSM Sénégal (léger pour le dev) |

**Livrable Sprint 3** : un dispatcher peut créer une commande, VROOM optimise l'affectation, le chauffeur reçoit ses tâches ordonnées, capture une POD. Le client suit son colis par lien.

---

#### Sprint 4 — Facturation + paiement mobile money (semaines 9-10)

**Objectif** : tarifs, factures, paiement Wave/Orange Money.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles PriceList, PriceRule + admin | 1.5 | Grilles tarifaires configurables par tenant |
| PricingEngine : calcul tarif voyage (fixe par route) + colis (par zone/kg/km) | 1.5 | `POST /billing/pricing/calculate` |
| Modèles Invoice, InvoiceLine + admin + génération auto | 1.5 | Factures liées aux réservations et commandes |
| Modèles Payment + providers | 2 | Interface PaymentProvider + intégration CinetPay sandbox |
| `POST /billing/payments/initiate` + webhook callback | 2 | Flux complet : initiation → callback → confirmation |
| Celery tasks : vérification statut paiement, retry avec backoff | 1 | Résilience aux timeouts mobile money |
| Intégration Payment ↔ Workflow : paiement OK → transition reservation/order | 0.5 | Automatisation du flux |

**Livrable Sprint 4** : un passager paie son billet via Wave ou Orange Money. Le paiement déclenche la confirmation de réservation et l'envoi du billet QR.

**⚠️ Point contractuel** : le contrat avec l'agrégateur (CinetPay, PayDunya, Bizao) doit être signé avant ce sprint. Le PoC sandbox peut commencer dès le Sprint 0 mais le go-live nécessite un contrat commercial et des credentials de production.

---

#### Sprint 5 — Tracking GPS + notifications (semaines 11-12)

**Objectif** : tracking temps réel des véhicules, notifications SMS/WhatsApp/push.

| Tâche | Jours | Livrable |
|---|---|---|
| Setup container Traccar + configuration protocoles GPS | 1 | Traccar fonctionnel |
| TraccarBridge : sync positions Traccar → table `positions` PostgreSQL | 1.5 | Positions en DB, requêtables |
| Modèles Geofence, GeofenceEvent + admin + vérification spatiale | 1.5 | Alertes entrée/sortie de zone |
| Django Channels : WebSocket consumer positions live | 1.5 | `/ws/tracking/live/` — positions en temps réel sur la console |
| Module notifications : modèles, providers (Africa's Talking SMS, Firebase Push) | 2 | Templates + envoi asynchrone |
| Intégration Workflow hooks → notifications | 1 | Transition de statut → notification automatique |
| WhatsApp Business API (si accès au moment du sprint, sinon reporté) | 1 | Notifications WhatsApp |

**Livrable Sprint 5** : le dispatcher voit les véhicules bouger sur une carte en temps réel. Les passagers reçoivent un SMS de confirmation de réservation et un rappel de départ.

---

#### Sprint 6 — Reporting + hardening + OSRM Afrique Ouest (semaines 13-14)

**Objectif** : dashboards admin, sécurité, performance, données OSRM complètes.

| Tâche | Jours | Livrable |
|---|---|---|
| Admin unfold : dashboards KPI (voyages/jour, taux remplissage, CA, anomalies) | 2 | Widgets dashboard dans l'admin |
| Export PDF manifeste (Celery + WeasyPrint) | 1 | PDF téléchargeable depuis l'admin |
| Export Excel rapports (openpyxl via Celery) | 1 | Export Excel des données filtrées |
| Pré-traitement OSRM Afrique de l'Ouest complète (§4.3) | 1 | Données OSM 15 pays opérationnelles |
| Tests de charge : locust sur les endpoints critiques | 1 | Validation < 2s sous charge (CdC §6.1) |
| Audit sécurité : headers, CORS, rate limiting, secrets rotation | 1 | Hardening prod |
| Module `api_credentials` : génération + validation clés API tenant | 1 | API publique prête pour intégrations tierces |
| Documentation API : drf-spectacular → Swagger UI | 1 | `/api/docs/` auto-généré |
| Purge automatique positions GPS > 90 jours (Celery Beat) | 0.5 | Conformité RGPD-like géoloc |

---

#### Sprint 7 — Déploiement prod + polish (semaines 15-16)

**Objectif** : mise en production, formation, données réelles.

| Tâche | Jours | Livrable |
|---|---|---|
| Setup serveur prod cloud souverain SN | 1.5 | Docker Compose prod, TLS, firewall |
| Deployment pipeline staging → prod (GitHub Actions §4.5) | 1 | CI/CD complet |
| Backups automatisés (§4.6) + test de restauration | 1 | Backup PostgreSQL + media quotidien |
| Monitoring (UptimeRobot + Sentry) | 0.5 | Alertes en place |
| Seed données réelles premier tenant (avec le client) | 1 | Routes, véhicules, chauffeurs, horaires, tarifs |
| Formation dispatcher + admin tenant | 1 | Session vidéo enregistrée |
| Formation contrôleur (avec l'app RN) | 1 | Scénario démo live |
| Dry-run : 1 journée d'exploitation simulée | 1 | Scénario bout-en-bout validé |
| Bug fixes et polish | 2 | Zéro bug bloquant |

**🎯 Go-live V1 : semaine 16 (~mi-décembre 2026)**

---

### 5.2 Vue chronologique

```
Août 2026         Sept              Oct               Nov               Dec
 S0──────S1──────S2──────S3──────S4──────S5──────S6──────S7───→ GO LIVE
 │        │        │        │        │        │        │        │
 Fondations│  Offline │   Colis  │ Paiement│ Tracking │ Report  │ Prod
         Voyage    sync    +VROOM  MoMo    +Notif   +Sécu    Deploy
         core    +Anomal                                     
                    │
                    ▼
              App RN reconnectée
              au nouveau backend
```

**Durée totale : 16 semaines (~4 mois).** C'est 2-4 mois plus court que l'estimation initiale de l'étude (6-8 mois) grâce à :
- Le domain knowledge accumulé sur 2 sprints Fleetbase
- Le contrat API déjà documenté et testé (OpenAPI + Postman)
- Le schéma DB déjà conçu (46 tables) et validé pour 10 d'entre elles
- Le protocole offline-sync déjà spécifié et testé
- L'app contrôleur RN qui continue en parallèle sans interruption

---

### 5.3 Risques et mitigation

| Risque | Probabilité | Impact | Mitigation |
|---|---|---|---|
| Port du ControlEventProcessor plus long que prévu (481 lignes PHP → Python) | Moyenne | Élevé (bloque le Sprint 2) | Commencer par un port ligne-à-ligne avant de refactorer. Les tests Postman servent de filet |
| Provider cloud souverain SN n'offre pas le SLA 99.9% | Moyenne | Moyen | Identifier 2 providers dès le Sprint 0. Plan B : serveur dédié en colocation Etix |
| Contrat agrégateur mobile money non signé avant Sprint 4 | Haute | Élevé (bloque le paiement) | Lancer la discussion commerciale dès le Sprint 0. Développer sur sandbox CinetPay, passer en prod quand le contrat est signé |
| OSRM Afrique de l'Ouest trop lourd pour le serveur | Faible | Moyen | Commencer avec les données Sénégal seul (Sprint 0-5), passer à l'Afrique de l'Ouest quand le serveur prod est dimensionné (Sprint 6) |
| L'app RN ne s'adapte pas au changement de base URL | Très faible | Faible | Le contrat API est identique. Seule la base URL change → 1 variable d'environnement côté app |
| Recrutement d'un 2ᵉ dev retardé | Moyenne | Moyen | Le planning est conçu pour 1 dev backend senior. Un 2ᵉ dev accélère les Sprints 3-6 mais n'est pas bloquant |

---

### 5.4 Ce qui est hors scope V1 (backlog V1.5/V2)

| Feature | Pourquoi hors scope V1 | Sprint estimé |
|---|---|---|
| Console React custom (carte dispatcher, Kanban, plan sièges visuel) | Django Admin + unfold suffit pour le V1 | V1.5 : 3-4 sprints |
| App Client (voyage + colis) | Le V1 se concentre sur l'opérationnel (contrôleur, chauffeur, dispatcher). L'app client est critique mais peut être décalée | V1.5 : 4-6 sprints |
| App Chauffeur | Le chauffeur V1 utilise l'app Traccar (tracking GPS) + un simple PWA. App native V1.5 | V1.5 : 2-3 sprints |
| ERP integration (Odoo, SAP) | Pas de client V1 qui l'exige | V2 : à la demande |
| IA / optimisation prédictive | CdC §2.3 long terme | V2+ |
| Multi-langue complet (EN, Wolof) | V1 en français, EN partiel | V1.5 |
| Elasticsearch (recherche full-text avancée) | PostgreSQL full-text suffit V1 | V2 si volumes |
| Kubernetes | Docker Compose suffit V1 | Quand >500 véhicules trackés |
