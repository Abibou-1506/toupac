# TOUPAC — Architecture Document v1.0

## Section 4 — Infrastructure & déploiement

### 4.1 Topologie Docker Compose (production)

9 services depuis 5 images distinctes. Les 3 services Django partagent la même image (entrypoint différent).

```yaml
# docker-compose.prod.yml — structure simplifiée
services:

  # ─── Reverse proxy ───
  caddy:
    image: caddy:2-alpine
    ports: ["443:443", "80:80"]
    # TLS automatique via Let's Encrypt (ou cert manuel cloud souverain)
    # Proxy: /api/* → toupac-web:8000
    # Proxy: /ws/*  → toupac-ws:8001
    # Proxy: /admin/* → toupac-web:8000
    # Static files: /static/* → volume partagé
    volumes: [caddy_data:/data, static_files:/srv/static:ro]
    restart: always
    mem_limit: 128m

  # ─── Django : API + Admin ───
  toupac-web:
    image: toupac/app:${TAG}
    command: >
      gunicorn config.wsgi:application
      --bind 0.0.0.0:8000
      --workers 4
      --worker-class uvicorn.workers.UvicornWorker
      --timeout 30
      --access-logfile -
    env_file: .env.prod
    volumes: [static_files:/app/staticfiles, media_files:/app/media]
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 1g
    # healthcheck: curl -f http://localhost:8000/health/

  # ─── Django : Celery worker ───
  toupac-worker:
    image: toupac/app:${TAG}
    command: >
      celery -A config worker
      --loglevel=info
      --concurrency=4
      --max-tasks-per-child=1000
    env_file: .env.prod
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 1g

  # ─── Django : Celery Beat (scheduler) ───
  toupac-beat:
    image: toupac/app:${TAG}
    command: celery -A config beat --loglevel=info --scheduler django_celery_beat.schedulers:DatabaseScheduler
    env_file: .env.prod
    depends_on: [postgres, redis]
    restart: always
    mem_limit: 256m

  # ─── Django : WebSocket (Channels) ───
  toupac-ws:
    image: toupac/app:${TAG}
    command: daphne -b 0.0.0.0 -p 8001 config.asgi:application
    env_file: .env.prod
    depends_on: [redis]
    restart: always
    mem_limit: 512m

  # ─── PostgreSQL + PostGIS ───
  postgres:
    image: postgis/postgis:16-3.4-alpine
    volumes: [pg_data:/var/lib/postgresql/data]
    environment:
      POSTGRES_DB: toupac
      POSTGRES_USER: toupac
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    restart: always
    mem_limit: 2g
    # pg_hba.conf : connexions locales uniquement (pas d'accès externe)

  # ─── Redis ───
  redis:
    image: redis:7-alpine
    command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru --appendonly yes
    volumes: [redis_data:/data]
    restart: always
    mem_limit: 384m

  # ─── Traccar (tracking GPS) ───
  traccar:
    image: traccar/traccar:6-alpine
    ports: ["5055:5055/tcp", "5055:5055/udp"]
    # Port 5055 = protocole OsmAnd (apps mobiles)
    # Ports additionnels selon les trackers GPS physiques utilisés
    volumes: [traccar_data:/opt/traccar/data]
    environment:
      # Traccar peut utiliser PostgreSQL partagé ou sa DB H2 interne
      CONFIG_FILE: /opt/traccar/conf/traccar.xml
    restart: always
    mem_limit: 512m

  # ─── OSRM (routing Afrique de l'Ouest) ───
  osrm:
    image: ghcr.io/project-osrm/osrm-backend:v5.27.1
    command: osrm-routed --algorithm mld /data/africa-west-latest.osrm
    volumes: [osrm_data:/data:ro]
    restart: always
    mem_limit: 6g
    # Données pré-processées hors container (voir §4.3)

  # ─── VROOM (optimisation tournées) ───
  vroom:
    image: vroomvrp/vroom-docker:v1.14.0
    environment:
      VROOM_ROUTER: osrm
      OSRM_URL: http://osrm:5000
    restart: always
    mem_limit: 512m

volumes:
  pg_data:
  redis_data:
  caddy_data:
  static_files:
  media_files:
  traccar_data:
  osrm_data:
```

#### Bilan des ressources (estimation prod initiale)

| Service | RAM | CPU | Stockage |
|---|---|---|---|
| Caddy | 128 Mo | 0.1 vCPU | Négligeable |
| toupac-web (4 workers) | 1 Go | 1 vCPU | — |
| toupac-worker (4 workers) | 1 Go | 1 vCPU | — |
| toupac-beat | 256 Mo | 0.1 vCPU | — |
| toupac-ws (Daphne) | 512 Mo | 0.5 vCPU | — |
| PostgreSQL + PostGIS | 2 Go | 1 vCPU | 50 Go SSD (croissance ~1 Go/mois) |
| Redis | 384 Mo | 0.2 vCPU | 1 Go |
| Traccar | 512 Mo | 0.5 vCPU | 10 Go |
| OSRM (Afrique Ouest) | **6 Go** | 1 vCPU | 15 Go (données OSM pré-processées) |
| VROOM | 512 Mo | 0.5 vCPU | — |
| **Total** | **~12 Go** | **~6 vCPU** | **~80 Go SSD** |

**Recommandation serveur** : VPS 8 vCPU / 16 Go RAM / 200 Go SSD NVMe pour démarrer. Marge de 4 Go pour les pics. Passer à 32 Go RAM quand le nombre de véhicules trackés dépasse 200 en simultané (Traccar + OSRM sous charge).

---

### 4.2 Cloud souverain sénégalais

**Ce que dit la contrainte** : les données doivent être hébergées au Sénégal. Les données de clients ivoiriens, maliens, etc. sont hébergées au SN — les CGU TOUPAC doivent le mentionner explicitement.

**Options de providers** (à valider avec la direction — les prix évoluent) :

| Provider | Offre | Avantage | Point d'attention |
|---|---|---|---|
| **Africa Cloud / Sonatel** | VPS, bare metal, object storage | Infrastructure Sonatel/Orange, peering local excellent | Vérifier SLA 99.9%, support Docker |
| **CGSI (Centre de Gestion des Systèmes Informatiques)** | Hébergement datacenter Dakar | Souveraineté gouvernementale | Destiné aux institutions, vérifier éligibilité privée |
| **Etix Everywhere Dakar** | Colocation datacenter Tier III | Fiabilité, certifications | Colocation = on gère le serveur soi-même |
| **VPS international avec contrainte Dakar** | OVH, Hetzner, DigitalOcean | Pas de datacenter à Dakar | ❌ Ne satisfait pas la contrainte |

**Ce que je recommande** : contacter Africa Cloud / Sonatel et Etix Everywhere pour un devis VPS 8 vCPU / 16 Go / 200 Go. Budget estimé : 150 000 à 300 000 XOF/mois (~230-460 €). L'alternative est un serveur dédié en colocation chez Etix (~500-800 €/mois avec le matériel amorti sur 3 ans).

**Backup du backup** : si aucun provider souverain n'offre un SLA 99.9% acceptable, un setup multi-site est envisageable : primaire au SN (données), CDN + failover hors SN (statique uniquement, pas de données personnelles). Mais ça complexifie l'opérationnel — à éviter en V1.

---

### 4.3 OSRM — données Afrique de l'Ouest

OSRM a besoin de données OpenStreetMap pré-processées. Pour couvrir les 15 pays UEMOA + CEDEAO :

```bash
# Télécharger l'extrait Geofabrik Afrique de l'Ouest (~1.2 Go)
wget https://download.geofabrik.de/africa/western-africa-latest.osm.pbf

# Pré-traitement (à faire sur une machine avec ≥8 Go RAM, pas sur le serveur prod)
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-extract -p /opt/car.lua /data/western-africa-latest.osm.pbf
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-partition /data/western-africa-latest.osrm
docker run --rm -v $(pwd):/data ghcr.io/project-osrm/osrm-backend:v5.27.1 \
  osrm-customize /data/western-africa-latest.osrm

# Résultat : ~5-8 Go de fichiers .osrm.* à monter dans le container prod
```

**Mise à jour mensuelle** : Geofabrik met à jour ses extraits quotidiennement. Un cron mensuel télécharge, pré-traite sur un serveur de build, et remplace les fichiers sur le serveur prod (volume Docker). Downtime OSRM : ~2 minutes (restart du container).

**Profil de routing** : `car.lua` par défaut. Si TOUPAC gère des motos ou des vélos (livraison urbaine), il faudra des profils additionnels. Chaque profil = un jeu de données pré-traité séparé (~5 Go de plus par profil).

---

### 4.4 Object Storage (S3-compatible)

Photos (POD, incidents, CNI passagers), documents (factures PDF, manifestes), fichiers uploadés. Ne pas stocker ça dans PostgreSQL.

| Option | Notes |
|---|---|
| **MinIO** (self-hosted) | S3-compatible, 1 container de plus, gratuit. Recommandé V1 si pas d'offre S3 chez le provider souverain |
| **Object storage du provider** | Si Africa Cloud / Sonatel propose un stockage objet S3-compatible, l'utiliser plutôt que self-hosted |

Django utilise `django-storages` avec le backend S3 — transparent, les fichiers sont accédés par URL signée (pas de lecture directe depuis la DB).

Estimation stockage : ~5 Go/mois/tenant actif (photos POD, documents). Prévoir 100 Go pour la première année tous tenants confondus.

---

### 4.5 CI/CD — GitHub Actions

```yaml
# .github/workflows/ci.yml
name: CI/CD TOUPAC

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgis/postgis:16-3.4-alpine
        env:
          POSTGRES_DB: toupac_test
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
        ports: ["5432:5432"]
      redis:
        image: redis:7-alpine
        ports: ["6379:6379"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pip install -r requirements/dev.txt
      - run: python manage.py migrate --settings=config.settings.test
      - run: pytest --cov=. --cov-report=xml -x
      - run: ruff check .
      - run: ruff format --check .

  build:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/build-push-action@v5
        with:
          push: true
          tags: toupac/app:${{ github.sha }},toupac/app:latest
          # Registry privé (GitHub Container Registry ou registry self-hosted)

  deploy-staging:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - name: Deploy via SSH
        run: |
          ssh deploy@staging.toupac.sn "
            cd /opt/toupac &&
            docker compose pull &&
            docker compose up -d --remove-orphans &&
            docker compose exec -T toupac-web python manage.py migrate --no-input &&
            docker compose exec -T toupac-web python manage.py collectstatic --no-input
          "

  deploy-prod:
    needs: build
    if: github.ref == 'refs/heads/main'
    environment: production   # Require manual approval
    runs-on: ubuntu-latest
    steps:
      - name: Deploy via SSH
        run: |
          ssh deploy@api.toupac.sn "
            cd /opt/toupac &&
            TAG=${{ github.sha }} docker compose -f docker-compose.prod.yml pull &&
            TAG=${{ github.sha }} docker compose -f docker-compose.prod.yml up -d --remove-orphans &&
            docker compose exec -T toupac-web python manage.py migrate --no-input
          "
```

**Branching** : `develop` pour l'intégration continue (déploie sur staging auto), `main` pour la prod (déploie après approbation manuelle via GitHub Environments).

---

### 4.6 Backups

| Quoi | Fréquence | Rétention | Comment |
|---|---|---|---|
| PostgreSQL (dump complet) | Quotidien, 3h du matin UTC | 30 jours | `pg_dump --format=custom` → objet storage ou stockage externe |
| PostgreSQL (WAL archiving) | Continu | 7 jours | Point-in-time recovery en cas de corruption |
| Redis (RDB snapshot) | Toutes les heures | 48h | Persistence AOF activée, snapshot RDB en complément |
| Object storage (media) | Quotidien (incremental) | 90 jours | `rclone sync` vers un second emplacement |
| Volumes Docker (Traccar, OSRM) | Hebdomadaire | 4 semaines | Reconstituable depuis les sources, backup de confort |

**Test de restauration** : une fois par mois, restaurer le backup PostgreSQL sur l'environnement staging et vérifier l'intégrité. Automatiser ce test dans le CI (job mensuel).

**Chiffrement** : les backups PostgreSQL sont chiffrés au repos (GPG ou age) avant transfert. La clé de chiffrement est stockée hors du serveur de backup (gestionnaire de secrets ou coffre-fort physique).

---

### 4.7 Monitoring & observabilité

Stack légère, pas de cluster Prometheus/Grafana en V1 (budget startup).

| Couche | Outil | Coût |
|---|---|---|
| **Uptime** | UptimeRobot ou Hetrix (plan gratuit) | 0 € — check HTTP toutes les 5 min, alertes SMS/email |
| **Logs** | Docker JSON logs + `docker compose logs --tail=1000` | 0 € — suffisant V1 |
| **Logs (upgrade V1.5)** | Loki + Grafana (self-hosted, 1 container) | 0 € — quand les logs Docker bruts ne suffisent plus |
| **Métriques applicatives** | `django-prometheus` → Prometheus (self-hosted) | 0 € — expose /metrics, un container Prometheus scrape |
| **Métriques système** | `node_exporter` + Prometheus | 0 € — CPU, RAM, disk, réseau |
| **APM (traces)** | Sentry self-hosted ou sentry.io (plan dev gratuit) | 0 € — traces d'erreurs Python avec stack trace et contexte |
| **Alertes** | Prometheus Alertmanager ou UptimeRobot | SMS/email quand : CPU > 80% 5min, RAM > 90%, disk > 85%, 5xx > 10/min, Celery queue > 100 |

**V1 minimal** : UptimeRobot (gratuit, 5 monitors) + Sentry (plan dev, 5000 events/mois) + `docker compose logs`. Ça couvre les pannes et les erreurs applicatives. Le reste vient quand l'équipe grandit.

---

### 4.8 Sécurité

| Mesure | Implémentation |
|---|---|
| **TLS partout** | Caddy gère les certificats Let's Encrypt automatiquement. Si le provider souverain n'expose pas les ports 80/443, cert manuel + Caddy en mode TLS passthrough |
| **Firewall** | UFW : seuls les ports 80, 443, 22 (SSH) et 5055 (Traccar GPS) sont ouverts. PostgreSQL, Redis, OSRM, VROOM ne sont PAS exposés — communication inter-container uniquement |
| **SSH** | Clé ED25519 uniquement, password auth désactivé, fail2ban |
| **Secrets** | `.env.prod` avec `chmod 600`, jamais commité. V2 : Vault ou SOPS |
| **DB** | `pg_hba.conf` : connexions locales (socket unix) et réseau Docker uniquement. Pas d'accès TCP externe |
| **Django** | `SECURE_HSTS_SECONDS`, `CSRF_COOKIE_SECURE`, `SESSION_COOKIE_SECURE`, `SECURE_SSL_REDIRECT` — tous à true en prod |
| **Rate limiting** | DRF throttling par tenant (§3.4). Caddy rate-limit global en complément |
| **Headers** | `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Content-Security-Policy` — via Caddy |
| **Dépendances** | `pip-audit` + `safety` dans le CI. Dependabot activé sur GitHub |
| **RGPD-like géoloc chauffeurs** | Les positions GPS sont purgées après 90 jours (Celery Beat task). Accès aux CNI passagers audité dans `passenger_access_log` (§Sprint 2 pattern) |

---

## Section 5 — Roadmap de migration

### 5.0 Point de départ

On part d'ici (24 août 2026) :

| Actif | Statut | Portabilité |
|---|---|---|
| 19 endpoints API documentés (OpenAPI v1.1.0) | ✅ Validé | Spécification pour la réécriture Django |
| Collection Postman 20 requêtes | ✅ Validé | Tests de non-régression |
| Schéma DB 12 tables custom | ✅ Validé | Migration DDL directe (10 tables portées, 2 supprimées) |
| Protocole offline-sync (ControlEventProcessor, 481 lignes) | ✅ Validé | Port en Python, logique métier identique |
| QR billet JWT RS256 | ✅ Validé | `PyJWT` + clé RSA |
| Test multi-tenant 8/8 | ✅ Validé | Pattern `tenant_id` directement applicable |
| App contrôleur React Native (équipier séparé) | 🔄 En cours | Continue en parallèle, consomme l'API v1 identique |
| Figma (3 apps mobiles) | ✅ Disponible | Référence UX inchangée |
| Cahier des charges | ✅ Disponible | Inchangé |

**Deadline MVP initiale** : 19 septembre 2026 (J5-STATE §8). Cette date est **caduque** pour le backend — le pivot de stack impose un nouveau calendrier. L'app contrôleur React Native continue sur son planning propre (elle consomme l'API, elle n'est pas couplée au framework backend).

---

### 5.1 Planning par sprint (2 semaines chacun)

#### Sprint 0 — Fondations (semaines 1-2)

**Objectif** : projet Django bootable, CI verte, premiers modèles en DB, admin fonctionnel.

| Tâche | Jours | Livrable |
|---|---|---|
| Init projet Django 5 + DRF + config settings (dev/staging/prod) | 1 | Repo GitHub, structure §3.1 |
| Docker Compose dev (Django + PostgreSQL/PostGIS + Redis) | 1 | `docker compose up` fonctionnel |
| Module `core` : TenantModel, UUIDv7Field, TenantMiddleware, TenantQuerySetMixin | 1 | Base technique multi-tenant |
| Module `iam` : modèles Tenant, User + Django Admin + unfold | 1 | Admin accessible, création tenant/user |
| Module `iam` : auth JWT (simplejwt) + denylist jti (port du pattern §4.19) | 1 | `POST /auth/login`, `POST /auth/refresh`, `POST /auth/logout` |
| CI GitHub Actions : pytest + ruff + build Docker | 0.5 | Pipeline verte |
| Module `workflow` : modèles WorkflowDefinition, WorkflowState, WorkflowTransition, WorkflowHook | 1 | Tables créées, admin CRUD |
| Seed workflows système (Trip, Order, DeliveryTask) | 0.5 | Workflows par défaut en DB |
| Module `fleet` : Vehicle, Driver, VehicleType (modèles + admin) | 1 | CRUD véhicules/chauffeurs dans l'admin |
| Module `geo` : Place, Zone (PostGIS + admin django-leaflet) | 1 | Places avec carte dans l'admin |
| **Démo interne** | — | Admin multi-tenant : créer un tenant, des users, des véhicules, des chauffeurs, des places sur une carte |

**Livrable Sprint 0** : Django Admin fonctionnel avec multi-tenant, auth JWT, CRUD flotte et géographie.

---

#### Sprint 1 — Module Voyage core (semaines 3-4)

**Objectif** : port des 10 tables voyage + les 4 nouvelles (routes, route_stops, schedules, trip_stops). API voyage reconstituée.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles Route, RouteStop, Schedule, SeatMap, LuggagePolicy + admin | 2 | Gestion des lignes et horaires dans l'admin |
| Modèles Trip, TripStop + WorkflowEngine intégration + admin | 2 | Création de voyages, transitions de statut via admin |
| Modèles Passenger, Reservation + QR JWT RS256 (`PyJWT`) | 1.5 | Port direct des tables Sprint 2 |
| Modèles Controller, ControlSession | 0.5 | Port direct |
| API DRF : endpoints Trips (list, detail, manifest) | 1.5 | `GET /voyage/trips/`, `GET /voyage/trips/{id}/manifest` |
| API DRF : endpoints Auth contrôleur (login, refresh, logout) | 1 | Port des 3 endpoints Sprint 2 |
| API DRF : endpoints Reservations (board, refuse, special-case, onboard sale) | 1.5 | Port des 4 endpoints Sprint 2 |
| **Validation Postman** | — | Rejouer la collection Postman Sprint 2 sur la nouvelle API |

**Livrable Sprint 1** : API voyage fonctionnelle, validée par la collection Postman existante. L'app contrôleur React Native peut pointer dessus.

---

#### Sprint 2 — Offline sync + anomalies (semaines 5-6)

**Objectif** : port du ControlEventProcessor et du protocole offline complet.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles ControlEvent, Anomaly, Incident, CashEntry | 1 | Port direct des 4 tables restantes |
| IdempotencyMiddleware (header `Idempotency-Key`, cache Redis) | 1 | Idempotence sur tous les POST |
| Port du ControlEventProcessor (481 lignes PHP → Python) | 3 | Dispatch des 10 event_type + auto-anomalies |
| API DRF : `POST /control-events/batch` | 1 | Endpoint critique offline sync |
| API DRF : anomalies, incidents, passengers, uploads/presign | 1.5 | Les 6 endpoints restants du Sprint 2 |
| WorkflowEngine : transitions Trip via ControlEventProcessor | 1 | `preparing → boarding` au premier board, etc. |
| Test multi-tenant (port du test 8/8 du Sprint 2 §6.2) | 0.5 | Aucune fuite cross-tenant |
| **Validation complète** | — | 20/20 endpoints Postman verts, isolation tenant validée |

**Livrable Sprint 2** : parité fonctionnelle complète avec le Sprint 2 Fleetbase. Tous les patterns validés (offline sync, idempotence, auto-anomalies, multi-tenant isolation) fonctionnent sur Django. L'app contrôleur React Native peut basculer sur le nouveau backend sans modification.

**⚠️ Milestone critique** : à ce stade, l'équipier React Native peut reconnecter son app au nouveau backend. Le contrat API (OpenAPI v1.1.0) est identique — seuls les URLs de base changent.

---

#### Sprint 3 — Module Colis (semaines 7-8)

**Objectif** : commandes de livraison, colis, dispatch, POD.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles Order, Parcel, DeliveryTask, ProofOfDelivery + admin | 2 | CRUD colis dans l'admin |
| WorkflowEngine : flow Order + flow DeliveryTask | 1 | State machines configurables |
| API DRF : CRUD orders, parcels, delivery-tasks, POD | 3 | API complète module colis |
| Intégration VROOM : `POST /colis/dispatch/optimize` | 1.5 | Appel HTTP vers container VROOM |
| Intégration OSRM : calcul ETA, route polyline | 1 | Appel HTTP vers container OSRM |
| Tracking links publics : `GET /tracking/links/{token}` | 0.5 | Suivi public par URL |
| Setup containers VROOM + OSRM en Docker Compose dev | 1 | Données OSM Sénégal (léger pour le dev) |

**Livrable Sprint 3** : un dispatcher peut créer une commande, VROOM optimise l'affectation, le chauffeur reçoit ses tâches ordonnées, capture une POD. Le client suit son colis par lien.

---

#### Sprint 4 — Facturation + paiement mobile money (semaines 9-10)

**Objectif** : tarifs, factures, paiement Wave/Orange Money.

| Tâche | Jours | Livrable |
|---|---|---|
| Modèles PriceList, PriceRule + admin | 1.5 | Grilles tarifaires configurables par tenant |
| PricingEngine : calcul tarif voyage (fixe par route) + colis (par zone/kg/km) | 1.5 | `POST /billing/pricing/calculate` |
| Modèles Invoice, InvoiceLine + admin + génération auto | 1.5 | Factures liées aux réservations et commandes |
| Modèles Payment + providers | 2 | Interface PaymentProvider + intégration CinetPay sandbox |
| `POST /billing/payments/initiate` + webhook callback | 2 | Flux complet : initiation → callback → confirmation |
| Celery tasks : vérification statut paiement, retry avec backoff | 1 | Résilience aux timeouts mobile money |
| Intégration Payment ↔ Workflow : paiement OK → transition reservation/order | 0.5 | Automatisation du flux |

**Livrable Sprint 4** : un passager paie son billet via Wave ou Orange Money. Le paiement déclenche la confirmation de réservation et l'envoi du billet QR.

**⚠️ Point contractuel** : le contrat avec l'agrégateur (CinetPay, PayDunya, Bizao) doit être signé avant ce sprint. Le PoC sandbox peut commencer dès le Sprint 0 mais le go-live nécessite un contrat commercial et des credentials de production.

---

#### Sprint 5 — Tracking GPS + notifications (semaines 11-12)

**Objectif** : tracking temps réel des véhicules, notifications SMS/WhatsApp/push.

| Tâche | Jours | Livrable |
|---|---|---|
| Setup container Traccar + configuration protocoles GPS | 1 | Traccar fonctionnel |
| TraccarBridge : sync positions Traccar → table `positions` PostgreSQL | 1.5 | Positions en DB, requêtables |
| Modèles Geofence, GeofenceEvent + admin + vérification spatiale | 1.5 | Alertes entrée/sortie de zone |
| Django Channels : WebSocket consumer positions live | 1.5 | `/ws/tracking/live/` — positions en temps réel sur la console |
| Module notifications : modèles, providers (Africa's Talking SMS, Firebase Push) | 2 | Templates + envoi asynchrone |
| Intégration Workflow hooks → notifications | 1 | Transition de statut → notification automatique |
| WhatsApp Business API (si accès au moment du sprint, sinon reporté) | 1 | Notifications WhatsApp |

**Livrable Sprint 5** : le dispatcher voit les véhicules bouger sur une carte en temps réel. Les passagers reçoivent un SMS de confirmation de réservation et un rappel de départ.

---

#### Sprint 6 — Reporting + hardening + OSRM Afrique Ouest (semaines 13-14)

**Objectif** : dashboards admin, sécurité, performance, données OSRM complètes.

| Tâche | Jours | Livrable |
|---|---|---|
| Admin unfold : dashboards KPI (voyages/jour, taux remplissage, CA, anomalies) | 2 | Widgets dashboard dans l'admin |
| Export PDF manifeste (Celery + WeasyPrint) | 1 | PDF téléchargeable depuis l'admin |
| Export Excel rapports (openpyxl via Celery) | 1 | Export Excel des données filtrées |
| Pré-traitement OSRM Afrique de l'Ouest complète (§4.3) | 1 | Données OSM 15 pays opérationnelles |
| Tests de charge : locust sur les endpoints critiques | 1 | Validation < 2s sous charge (CdC §6.1) |
| Audit sécurité : headers, CORS, rate limiting, secrets rotation | 1 | Hardening prod |
| Module `api_credentials` : génération + validation clés API tenant | 1 | API publique prête pour intégrations tierces |
| Documentation API : drf-spectacular → Swagger UI | 1 | `/api/docs/` auto-généré |
| Purge automatique positions GPS > 90 jours (Celery Beat) | 0.5 | Conformité RGPD-like géoloc |

---

#### Sprint 7 — Déploiement prod + polish (semaines 15-16)

**Objectif** : mise en production, formation, données réelles.

| Tâche | Jours | Livrable |
|---|---|---|
| Setup serveur prod cloud souverain SN | 1.5 | Docker Compose prod, TLS, firewall |
| Deployment pipeline staging → prod (GitHub Actions §4.5) | 1 | CI/CD complet |
| Backups automatisés (§4.6) + test de restauration | 1 | Backup PostgreSQL + media quotidien |
| Monitoring (UptimeRobot + Sentry) | 0.5 | Alertes en place |
| Seed données réelles premier tenant (avec le client) | 1 | Routes, véhicules, chauffeurs, horaires, tarifs |
| Formation dispatcher + admin tenant | 1 | Session vidéo enregistrée |
| Formation contrôleur (avec l'app RN) | 1 | Scénario démo live |
| Dry-run : 1 journée d'exploitation simulée | 1 | Scénario bout-en-bout validé |
| Bug fixes et polish | 2 | Zéro bug bloquant |

**🎯 Go-live V1 : semaine 16 (~mi-décembre 2026)**

---

### 5.2 Vue chronologique

```
Août 2026         Sept              Oct               Nov               Dec
 S0──────S1──────S2──────S3──────S4──────S5──────S6──────S7───→ GO LIVE
 │        │        │        │        │        │        │        │
 Fondations│  Offline │   Colis  │ Paiement│ Tracking │ Report  │ Prod
         Voyage    sync    +VROOM  MoMo    +Notif   +Sécu    Deploy
         core    +Anomal                                     
                    │
                    ▼
              App RN reconnectée
              au nouveau backend
```

**Durée totale : 16 semaines (~4 mois).** C'est 2-4 mois plus court que l'estimation initiale de l'étude (6-8 mois) grâce à :
- Le domain knowledge accumulé sur 2 sprints Fleetbase
- Le contrat API déjà documenté et testé (OpenAPI + Postman)
- Le schéma DB déjà conçu (46 tables) et validé pour 10 d'entre elles
- Le protocole offline-sync déjà spécifié et testé
- L'app contrôleur RN qui continue en parallèle sans interruption

---

### 5.3 Risques et mitigation

| Risque | Probabilité | Impact | Mitigation |
|---|---|---|---|
| Port du ControlEventProcessor plus long que prévu (481 lignes PHP → Python) | Moyenne | Élevé (bloque le Sprint 2) | Commencer par un port ligne-à-ligne avant de refactorer. Les tests Postman servent de filet |
| Provider cloud souverain SN n'offre pas le SLA 99.9% | Moyenne | Moyen | Identifier 2 providers dès le Sprint 0. Plan B : serveur dédié en colocation Etix |
| Contrat agrégateur mobile money non signé avant Sprint 4 | Haute | Élevé (bloque le paiement) | Lancer la discussion commerciale dès le Sprint 0. Développer sur sandbox CinetPay, passer en prod quand le contrat est signé |
| OSRM Afrique de l'Ouest trop lourd pour le serveur | Faible | Moyen | Commencer avec les données Sénégal seul (Sprint 0-5), passer à l'Afrique de l'Ouest quand le serveur prod est dimensionné (Sprint 6) |
| L'app RN ne s'adapte pas au changement de base URL | Très faible | Faible | Le contrat API est identique. Seule la base URL change → 1 variable d'environnement côté app |
| Recrutement d'un 2ᵉ dev retardé | Moyenne | Moyen | Le planning est conçu pour 1 dev backend senior. Un 2ᵉ dev accélère les Sprints 3-6 mais n'est pas bloquant |

---

### 5.4 Ce qui est hors scope V1 (backlog V1.5/V2)

| Feature | Pourquoi hors scope V1 | Sprint estimé |
|---|---|---|
| Console React custom (carte dispatcher, Kanban, plan sièges visuel) | Django Admin + unfold suffit pour le V1 | V1.5 : 3-4 sprints |
| App Client (voyage + colis) | Le V1 se concentre sur l'opérationnel (contrôleur, chauffeur, dispatcher). L'app client est critique mais peut être décalée | V1.5 : 4-6 sprints |
| App Chauffeur | Le chauffeur V1 utilise l'app Traccar (tracking GPS) + un simple PWA. App native V1.5 | V1.5 : 2-3 sprints |
| ERP integration (Odoo, SAP) | Pas de client V1 qui l'exige | V2 : à la demande |
| IA / optimisation prédictive | CdC §2.3 long terme | V2+ |
| Multi-langue complet (EN, Wolof) | V1 en français, EN partiel | V1.5 |
| Elasticsearch (recherche full-text avancée) | PostgreSQL full-text suffit V1 | V2 si volumes |
| Kubernetes | Docker Compose suffit V1 | Quand >500 véhicules trackés |
